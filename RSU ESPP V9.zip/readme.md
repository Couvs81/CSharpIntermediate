# RSU & ESPP Tracker — User Guide

A personal equity compensation tracker for Canadian employees receiving RSU and ESPP shares from their employer. Tracks vesting schedules, cost basis (ACB), capital gains/losses, and employment income — all saved locally in your browser.

---

## Getting Started

1. Download or copy the app folder to your computer
2. The folder contains three files: `index.html`, `style.css`, and `app.js`
3. Double-click `index.html` to open the app in your browser
4. No installation required. Internet is only used to auto-fetch Bank of Canada exchange rates

---

## How This App Is Structured

The app has seven sections accessible from the **left sidebar**:

- **Dashboard** — summary cards for shares held, total ACB, year-to-date gain/loss, and unvested shares remaining. Also shows upcoming vests and holdings tables (only grants/purchases with shares remaining are shown)
- **RSU Grants** — your grant batches, vest schedules, and per-period details
- **ESPP Purchases** — Employee Stock Purchase Plan entries with taxable benefit calculations
- **Dividends** — quarterly dividend payments (cash or DRIP reinvestment), with foreign income totals for T1 reporting and DRIP shares automatically added to your ACB pool
- **Sales** — every sale you record, with proceeds, ACB, and gain/loss calculated automatically
- **Gain / Loss** — capital gains report filtered to the selected tax year, with individual dispositions viewable in CAD, USD, or both. Includes an employment income reference table for T4 reconciliation
- **ACB Ledger** — a running log of every acquisition and sale (including DRIP shares), grouped by year in collapsible drawers, showing your weighted-average ACB at every point in time

The sidebar also contains data actions under the **Data** section: Export CSV, Save Backup, and Restore Backup. Clear All Data is pinned at the very bottom.

### Tax Year

The tax year is shown in the sidebar under the app title. Click directly on the year number to change it, then press Enter or click away. The Gain/Loss report and T4 employment income table will update to reflect the selected year. Your full transaction history is always preserved — only the report view changes.

---

## Canadian Tax Concepts This App Implements

### RSU Vesting — Two Separate Tax Events

When your RSUs vest, there are **two distinct tax events**:

**1. Employment Income on Vest Date**

On the vest date, the Fair Market Value (FMV) of the net shares you receive is **employment income** included on your T4. This is not a capital transaction.

- Taxable amount: **Net Shares Received × FMV/Share on Vest Date**
- Reported on T4 Box 14 (employment income)
- The shares sold for taxes (withheld by your broker to cover withholding) are not a disposition you report on Schedule 3
- Your employer reports this on your T4 automatically

**2. Capital Gain or Loss on Sale**

When you later sell the shares, that is a capital transaction:

**Proceeds of Disposition − Adjusted Cost Base (ACB) − Commissions = Capital Gain or Loss**

Your ACB is the FMV on the vest date — you already paid income tax on that amount, so using FMV as ACB prevents double taxation.

### ESPP — Employment Income and ACB

When you purchase shares through the ESPP at a 15% discount:

| Number | What It Represents |
|--------|-------------------|
| Purchase Price | What you actually paid (85% of FMV) |
| FMV on Purchase Date | The fair market value on the day of purchase |
| Taxable Benefit | FMV − Purchase Price = the 15% discount, reported as employment income on your T4 (Box 38) |

Your **ACB for capital gains purposes is the FMV on the purchase date**, not what you paid. The discount is already taxed as employment income — using FMV as ACB prevents being taxed on it again as a capital gain. This is governed by *Income Tax Act* s.7(1.3).

### Weighted-Average ACB (The CRA Rule for Identical Properties)

Shares from different grants and vest periods are **identical properties** under CRA rules. You cannot track cost basis per lot (no FIFO, no specific identification).

CRA requires a **single pooled weighted-average ACB** for all shares of the same company. Every acquisition (vest, ESPP purchase, or DRIP reinvestment) adds to the pool. Every sale uses the average cost per share in the pool at that moment.

**Example:**
- Vest 7 shares at US$264.50 → pool: 7 shares, ACB = US$1,851.50
- Vest 2 shares at US$261.93 → pool: 9 shares, ACB = US$2,375.36 (avg US$263.93/share)
- Sell 3 shares → ACB of sold = 3 × US$263.93 = US$791.79
- Remaining pool: 6 shares, ACB = US$1,583.57

**The Source Breakdown on the Sales form** (which grant, which vest period) is for your own tracking only. It does not affect the ACB calculation — that always uses the pool average.

### Currency — USD Amounts and CAD for Tax Reporting

All RSU and ESPP shares are priced in USD. For Canadian tax purposes:

- Report proceeds and ACB **in Canadian dollars**
- Use the **Bank of Canada exchange rate on the date of each transaction**
- This app uses the Bank of Canada Valet API to auto-fetch the rate for any date you enter
- Both USD and CAD amounts are tracked throughout
- Your T1 Schedule 3 entries should use the **CAD amounts**

---

## Dashboard

The four summary cards show:

| Card | What It Shows |
|------|--------------|
| Shares Held (Net Received) | Total shares received across all vested periods, minus shares sold. See ACB Ledger for full detail |
| Total ACB of Remaining Shares (CAD) | The current ACB pool in CAD — the cost base of the shares you still hold. See ACB Ledger |
| [Year] Gain / Loss (CAD) | Net capital gain or loss from sales in the selected tax year. See Gain / Loss tab |
| Unvested Shares Remaining | Shares scheduled to vest in future periods across all active grants. See RSU Grants tab |

The **Holdings by Grant** and **Holdings by ESPP Purchase** tables below the cards only show rows where you still have shares remaining — fully sold positions are hidden to keep the list manageable. The totals row always reflects all positions. ACB/Share columns reflect the blended pool average across all grants per CRA rules — ACB is not tracked per grant or purchase.

---

## RSU Grants Section

### Setting Up a Grant

1. Click **+ Add New Grant**
2. Enter the Grant Date, Grant Number (your award ID from your brokerage, e.g. B95009), Total Shares Granted, and optional notes
3. Optionally check **Prepopulate 13 vest dates** to auto-fill a standard schedule from the grant date
4. Add or adjust vest schedule rows — one row per vest period
5. Click **Save Grant**

Where to find this information in your brokerage (At Work):
- **Grant Date, Grant Number, Total Shares** → At Work › Holdings › Restricted Stock (RS) › Find your grant date › View Grant Documents
- **Vest Schedule dates** → At Work › Holdings › Restricted Stock (RS) › Find your grant date › Vest Schedule
- **Shares Sold for Taxes** → At Work › My Account › Stock Plan Confirmation › Employee Stock Plan Release Confirmation form

### Recording a Vest Event

When a vest occurs, click **Record Vest** on that row and enter:

- **Gross Shares Vested** — confirm or update from the scheduled amount
- **Shares Sold for Taxes** — shares your broker sold to cover withholding
- **Total FMV on Vest Date (USD)** — total dollar value of all vested shares (FMV/share is calculated from this)
- **FX Rate** — auto-fetched from Bank of Canada for the vest date; override if needed

The preview panel shows FMV/share, Net Shares Received, Cost (USD), Cost (CAD), and Cost/Share (CAD) before you save. Use **Save & Next** to move to the next vest row immediately.

### Overdue Vest Notifications

If any vest dates are in the past but not yet recorded, a warning banner appears on the Dashboard and a red badge appears on the RSU Grants sidebar item. These clear automatically once all past vests are recorded.

### Vest Schedule Columns

| Column | Description |
|--------|-------------|
| Vest Date | The date shares vest |
| Grant Qty | Shares scheduled to vest this period |
| Status | Vested (recorded), Overdue (past date, not recorded), or Future |
| Gross Vested | Shares that actually vested |
| FMV Total (USD) | Total FMV of all vested shares on vest date |
| FMV/Share (USD) | Per-share FMV (FMV Total ÷ Gross Vested) |
| Shares Sold for Taxes | Shares withheld by broker to cover income tax |
| Net Received | Shares you received = Gross Vested − Shares Sold for Taxes |
| FX Rate | USD→CAD rate on vest date (Bank of Canada) |
| Cost (USD / CAD) | ACB added to your pool = Net Received × FMV/Share |
| Sold | Shares from this period recorded as sold (tracking only) |
| Remaining | Net Received − Sold (tracking only) |

---

## ESPP Purchases Section

Click **+ Add New ESPP Purchase** to record a purchase period. You will need:

- **Purchase Date**
- **Shares Purchased**
- **Purchase Price/Share (USD)** — the discounted price you paid (85% of FMV)
- **FMV/Share on Purchase Date (USD)** — the market value on purchase date
- **FX Rate** — auto-fetched from Bank of Canada (enter either direction; the other is calculated automatically)

The app calculates and displays a preview showing purchase cost, FMV total, taxable benefit, and ACB/share in both USD and CAD before you save.

The **Shares Sold** and **Shares Remaining** columns are calculated automatically from the Sales tab.

An explanation of why ACB = FMV (not purchase price) is available at the bottom of the ESPP Purchases section.

---

---

## Dividends Section

Intuit pays dividends quarterly — typically the third Friday of January, April, July, and October. This section tracks each payment and handles both cash dividends and DRIP (Dividend Reinvestment Plan) reinvestments.

> **Important:** Dividend income is reported **separately from capital gains** on your T1 — as foreign income on line 12100 / Schedule 4. It is not included in the Gain / Loss report. The 15% US tax withheld at source is claimed as a foreign tax credit on your T1.

### Upcoming Payments Panel

The app estimates the next three expected dividend dates based on the Jan/Apr/Jul/Oct pattern and shows a "Record when received" button for each. Clicking this pre-fills the date in the entry form.

### Recording a Cash Dividend

Click **+ Record Dividend**, select **Cash**, and enter:

| Field | Where to find it |
|-------|-----------------|
| Payment date | Your E*TRADE/Morgan Stanley brokerage statement — Activity Date |
| Gross dividend (USD) | "Qualified Dividend" amount on your statement |
| US tax withheld (USD) | "Tax Withholding" line on your statement (typically 15%) |
| FX rate | Auto-fetched from Bank of Canada for the payment date |
| Notes | Optional — e.g. "Q1 2026" |

No shares are received and your ACB pool is not affected.

### Recording a DRIP Dividend

Click **+ Record Dividend**, select **DRIP**, and enter the same fields plus:

| Field | Where to find it |
|-------|-----------------|
| DRIP shares received | Number of shares purchased on your brokerage statement (may be fractional) |
| Price per DRIP share (USD) | The market price used to purchase the shares on the dividend date |

For DRIP entries the gross dividend value is still taxable foreign income in the year received — the same as if it had been paid as cash. The difference is that instead of receiving cash you receive shares, and those shares are added to your ACB pool at their purchase price.

### Reconciling with Your 1042-S

The **Annual Summary** table at the bottom of the Dividends section shows total gross dividends and withholding per year in both USD and CAD. At year end, compare these totals against your annual 1042-S form:
- App total gross (USD) should match **1042-S Box 2**
- App total withholding (USD) should match **1042-S Box 7**

### Summary Cards

The four cards at the top of the section reflect the selected tax year:

| Card | Description |
|------|-------------|
| Gross Dividend (CAD) | Total gross dividend income — report on T1 Schedule 4 |
| US Tax Withheld (CAD) | Total withholding — claim as foreign tax credit on T1 |
| Net Dividend (CAD) | Gross minus withholding |
| DRIP Shares Received | Shares added to your ACB pool this year via DRIP |

---

## Sales Section

### Recording a Sale

1. Click **+ Add New Sale**
2. Enter Sale Date, Shares Sold, Sale Price/Share (USD), FX Rate (auto-fetched), and Commission
3. Optionally add a **Source Breakdown** — indicate which grants and vest periods the shares came from. This is for your records only and does not affect the ACB calculation
4. The preview panel shows estimated proceeds, ACB being sold, and gain/loss before you save

### What the ACB Calculation Does

When you save a sale, the app:
1. Takes the weighted-average ACB per share at the time of sale (total pool ACB ÷ total shares)
2. Multiplies by shares sold to get the ACB of the disposed shares
3. Calculates gain/loss = Proceeds − ACB Sold − Commission
4. Reduces the remaining pool ACB accordingly

This is computed in both USD and CAD. The **CAD gain/loss** is what you report on CRA Schedule 3.

---

## Gain / Loss Report Section

Filtered to the tax year shown in the sidebar. The summary cards show:

| Card | Description |
|------|-------------|
| Total Proceeds (CAD) | Sum of all sale proceeds in CAD for the year |
| Total ACB (CAD) | ACB deducted for all sales in the year |
| Net Gain / Loss (CAD) | Proceeds − ACB − Commissions |
| Taxable Capital Gain (50%) | Net gain × 50% — report this on Schedule 3 |

The **50% inclusion rate** means only half your net capital gain is added to taxable income. Report the Taxable Capital Gain on **T1 Schedule 3, Section 3 (Publicly traded shares)**. Enter your employer's company name and stock ticker.

### Individual Dispositions

Use the **CAD / USD / Both** toggle buttons to switch views:

- **CAD** — simplified table: FX rate, Proceeds (CAD), ACB (CAD), Commission (CAD), Gain/Loss (CAD)
- **USD** — full table: Proceeds (USD), ACB (USD), Commission (USD), Gain/Loss (USD), then FX rate and all CAD equivalents
- **Both** — same as the USD view, which already includes all CAD columns

### Employment Income from RSU Vests & ESPP (T4)

Click **Unhide** to reveal this table. It shows the estimated employment income for the selected year from both sources, sorted by date:

- **RSU Vest rows** — employment income = Net Shares Received × FMV/Share, reported on **T4 Box 14**
- **ESPP rows** — employment income = (FMV − Purchase Price) × Shares, the 15% discount benefit, reported on **T4 Box 38**

> **Estimate only.** Your employer reports these amounts on your T4 using their own payroll FX rates. These figures are for reconciliation and reference — the T4 is the authoritative number for filing.

---

## ACB Ledger Section

A full audit trail of every event that affected your share pool, grouped by year in collapsible drawers. Click any year header to expand or collapse it. The most recent year is open by default.

Each year drawer shows:
- A **Carried Forward** row — the pool state carried into that year from prior activity
- One row per vest, ESPP purchase, DRIP dividend reinvestment, or sale event in that year

| Column | Description |
|--------|-------------|
| Date | Transaction date |
| Event | RSU Vest, ESPP Buy, DRIP Div, or Sale (colour-coded) |
| Grant / Source | Grant ID for vests, purchase date for ESPP, — for sales |
| Shares (+/-) | Change in share count (green = added, red = removed) |
| Cost Basis (USD / CAD) | Cost added (acquisitions) or ACB removed (sales) |
| Running Shares | Total shares in pool after this event |
| Running ACB (USD / CAD) | Total pool ACB after this event |
| ACB/Share (USD / CAD) | Weighted-average cost per share after this event |

---

## Saving and Backing Up Your Data

All data is saved automatically to your browser's **Local Storage** as you work.

> **Important:** Local Storage is tied to the specific browser on the specific computer you use. Clearing your browser cache or switching browsers will lose your data. Always keep a backup.

### Save Backup
- Click **Save Backup** in the sidebar under Data
- Saves a file named `equity-tracker-YYYY.json` to your Downloads folder
- This is your permanent backup — treat it like hitting Save in any other application
- Save after every session
- JSON backups from any previous version of the app can be imported into the current version without issues

### Restore Backup
- Click **Restore Backup** in the sidebar under Data
- Select a previously saved `.json` file
- **Warning:** This replaces all current data in the app. Save a backup first if needed

### Export to CSV
- Click **Export CSV** in the sidebar under Data
- Contains: RSU Grant Schedule, ESPP purchases, Sales history, Gain/Loss report for the current year, and the full ACB Ledger
- Use this for your tax records or to share with an accountant

### Clear All Data
- Click **Clear All Data** at the bottom of the sidebar
- Requires two confirmations — this cannot be undone
- Use this only when setting up the app for a brand new account. Always save a backup first
- This clears all grants, ESPP purchases, sales, and dividends

---

## Tips

- **Enter vests as they happen** — don't wait until tax time. The FX rate auto-fetch works best for recent dates
- **Always use Bank of Canada rates** — CRA expects BoC rates for foreign income conversion. The app fetches these automatically when you enter a date
- **If a vest date falls on a weekend or holiday**, the app returns the most recent prior business day's rate, which is the correct rate to use
- **Save a backup after every session** — it is the only reliable copy of your data outside the browser
- **The shares sold for taxes at vest are not a disposition** — do not report them on Schedule 3. They are accounted for in your T4 employment income
- **Check your brokerage statement** for the exact FMV and shares withheld on each vest date — these are the numbers to enter in the app
- **The Source Breakdown on sales is optional** — useful for your own records but does not affect any calculations
- **Enter dividends when you receive them** — the app will suggest the expected date based on the quarterly schedule
- **Reconcile your dividend entries against your 1042-S** at year end to make sure gross and withholding totals match before filing

---

## One App Per Account

If you have equity compensation from multiple employers or in multiple accounts, keep a separate app folder for each. Open each folder's `index.html` separately — each has its own independent Local Storage.
