// ============================================================
// DATA — load from localStorage or start fresh
// ============================================================
let grants   = JSON.parse(localStorage.getItem('rsu_grants'))   || [];
// Each grant: { id, grantDate, grantId, totalShares, notes, vests: [...] }
// Each vest:  { date, grossShares, withheld, netShares, fmvUSD, fx, vested:bool }

let esppPurchases = JSON.parse(localStorage.getItem('rsu_espp'))  || [];
// Each ESPP: { id, date, shares, purchasePriceUSD, fmvUSD, fx, notes }

let sales    = JSON.parse(localStorage.getItem('rsu_sales'))    || [];
// Each sale: { id, date, shares, priceUSD, fx, commissionUSD, notes }

let dividends = JSON.parse(localStorage.getItem('rsu_dividends')) || [];
// Each dividend: { date, type('cash'|'drip'), grossUSD, withheldUSD, fx, dripShares?, dripPriceUSD?, notes }

let skippedDivQuarters = JSON.parse(localStorage.getItem('rsu_div_skipped')) || [];
// Each entry: 'YYYY-MM' — month strings the user dismissed

let currentYear = JSON.parse(localStorage.getItem('rsu_year'))  || new Date().getFullYear();

// ── editing state ──
let editingGrantIdx  = null;
let editingVestInfo  = null; // { grantIdx, vestIdx }
let editingEsppIdx   = null;
let editingSaleIdx   = null;
let modalCallback    = null;

// ============================================================
// SAVE
// ============================================================
function saveData() {
  localStorage.setItem('rsu_grants', JSON.stringify(grants));
  localStorage.setItem('rsu_espp',   JSON.stringify(esppPurchases));
  localStorage.setItem('rsu_sales',  JSON.stringify(sales));
  localStorage.setItem('rsu_dividends', JSON.stringify(dividends));
  localStorage.setItem('rsu_div_skipped', JSON.stringify(skippedDivQuarters));
  localStorage.setItem('rsu_year',   JSON.stringify(currentYear));
}

// ============================================================
// FORMATTING
// ============================================================
const fmtUSD = v => 'US$' + Math.abs(+v||0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,',');
const fmtCAD = v => '$'   + Math.abs(+v||0).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,',');
const fmtN   = v => parseFloat((+v||0).toFixed(4)).toString();
const fmtSigned = (v, fmt) => (v < 0 ? '-' : '') + fmt(Math.abs(v));

function gainCell(v, fmt) {
  if (v === null || v === undefined || isNaN(v)) return '-';
  let cls = v >= 0 ? 'gain' : 'loss';
  return `<span class="${cls}">${fmtSigned(v, fmt)}</span>`;
}

// ============================================================
// TAX YEAR INPUT
// ============================================================
const yearInput = document.getElementById('tax-year');
yearInput.value = currentYear;
yearInput.addEventListener('change', function() {
  let v = parseInt(this.value);
  if (isNaN(v) || v < 2000 || v > 2100) { this.value = currentYear; return; }
  currentYear = v; saveData(); renderAll();
});

// ============================================================
// TOAST
// ============================================================
function showToast(msg) {
  let t = document.getElementById('toast');
  document.getElementById('toast-msg').textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(t._to);
  t._to = setTimeout(() => t.classList.add('hidden'), 4000);
}
document.getElementById('toast-close').addEventListener('click', () =>
  document.getElementById('toast').classList.add('hidden'));

// ============================================================
// NAVIGATION
// ============================================================
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => {
      p.classList.add('hidden');
      p.style.display = '';
    });
    this.classList.add('active');
    var sec = document.getElementById('section-' + this.dataset.section);
    if (!sec) return;
    sec.classList.remove('hidden');
    sec.style.display = 'block';
    window.scrollTo(0, 0);
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    // Re-render on every tab switch to keep data fresh
    if (typeof renderAll === 'function') renderAll();
  });
});

// ============================================================
// GREETING
// ============================================================
function updateGreeting() {
  var h = new Date().getHours();
  var el = document.getElementById('greeting-text');
  if (!el) return;
  if (h >= 5 && h < 12)      el.textContent = 'Good morning ☀';
  else if (h >= 12 && h < 17) el.textContent = 'Good afternoon 🌤';
  else if (h >= 17 && h < 21) el.textContent = 'Good evening 🌆';
  else                         el.textContent = 'Good night 🌙';
}
updateGreeting();
function showModal(title, msg, onConfirm) {
  document.getElementById('modal-title').textContent   = title;
  document.getElementById('modal-message').textContent = msg;
  document.getElementById('modal-overlay').classList.remove('hidden');
  modalCallback = onConfirm;
}
document.getElementById('modal-confirm').addEventListener('click', () => {
  document.getElementById('modal-overlay').classList.add('hidden');
  if (modalCallback) modalCallback();
  modalCallback = null;
});
document.getElementById('modal-cancel').addEventListener('click', () => {
  document.getElementById('modal-overlay').classList.add('hidden');
  modalCallback = null;
});

// ============================================================
// FX AUTO-FETCH
// ============================================================
async function fetchFX(dateStr, displayEl, targetInput) {
  if (!dateStr) return;
  if (displayEl) displayEl.textContent = 'Fetching rate…';
  try {
    let url = `https://www.bankofcanada.ca/valet/observations/FXUSDCAD/json?start_date=${dateStr}&end_date=${dateStr}`;
    let res = await fetch(url);
    let data = await res.json();
    let obs = data.observations;
    if (!obs || obs.length === 0) {
      // Date likely fell on a weekend/holiday — look back 14 days to find nearest business day
      let d = new Date(dateStr + 'T00:00:00');
      d.setDate(d.getDate() - 14);
      let startFallback = d.toISOString().split('T')[0];
      let url2 = `https://www.bankofcanada.ca/valet/observations/FXUSDCAD/json?start_date=${startFallback}&end_date=${dateStr}`;
      let res2 = await fetch(url2);
      let d2 = await res2.json();
      obs = d2.observations;
    }
    if (obs && obs.length > 0) {
      let rate = parseFloat(obs[obs.length-1].FXUSDCAD.v);
      let dt   = obs[obs.length-1].d;
      if (targetInput && !targetInput.value) targetInput.value = rate.toFixed(4);
      if (displayEl) displayEl.textContent = dt === dateStr
        ? `1 USD = ${rate.toFixed(4)} CAD (BoC ${dt})`
        : `1 USD = ${rate.toFixed(4)} CAD (BoC ${dt} — nearest prior business day)`;
    } else {
      if (displayEl) displayEl.textContent = 'No rate found — enter manually';
    }
  } catch(e) {
    if (displayEl) displayEl.textContent = 'Could not fetch rate — enter manually';
  }
}

// ── wire FX fetch to date fields ──
function wireFxFetch(dateId, fxId, displayId) {
  let di = document.getElementById(dateId);
  let fi = document.getElementById(fxId);
  let de = document.getElementById(displayId);
  if (!di) return;
  di.addEventListener('change', () => { fi.value = ''; fetchFX(di.value, de, fi); });
  fi.addEventListener('focus', () => { if (!fi.value) fetchFX(di.value, de, fi); });
}
wireFxFetch('ef-date',  'ef-fx',  'ef-fx-display');
wireFxFetch('sf-date',  'sf-fx',  'sf-fx-display');
wireFxFetch('vm-date',  'vm-fx',  'vm-fx-display');

// ── Bidirectional FX for ESPP — entering one calculates the other ──
function syncEsppFX(source) {
  let usdCad = document.getElementById('ef-fx');
  let cadUsd = document.getElementById('ef-fx-cad');
  let dispUSD = document.getElementById('ef-fx-display');
  let dispCAD = document.getElementById('ef-fx-cad-display');
  if (source === 'usdcad') {
    let v = parseFloat(usdCad.value);
    if (!isNaN(v) && v > 0) {
      cadUsd.value = (1 / v).toFixed(6);
      dispCAD.textContent = `= ${cadUsd.value} CAD→USD`;
    }
  } else {
    let v = parseFloat(cadUsd.value);
    if (!isNaN(v) && v > 0) {
      usdCad.value = (1 / v).toFixed(4);
      dispUSD.textContent = `1 USD = ${usdCad.value} CAD`;
    }
  }
  updateEsppPreview();
}
document.getElementById('ef-fx').addEventListener('input', () => syncEsppFX('usdcad'));
document.getElementById('ef-fx-cad').addEventListener('input', () => syncEsppFX('cadusd'));

// ============================================================
// UNIQUE ID
// ============================================================
let _id = 0;
function uid() { return Date.now().toString(36) + (++_id).toString(36); }

// ============================================================
// ACB ENGINE
// Weighted-average ACB pool (CRA rule for identical shares)
// Uses Decimal.js for exact base-10 arithmetic throughout.
// Returns chronological list of ACB events + running totals.
// ============================================================
function buildACBLedger() {
  const D = v => new Decimal(String(+v || 0));
  let events = [];

  // ── Collect all acquisition events ──
  for (let [gi, g] of grants.entries()) {
    for (let [vi, v] of g.vests.entries()) {
      if (!v.vested || !v.fmvUSD || !v.fx) continue;
      let net = D(v.netShares || 0).eq(0)
        ? D(v.grossShares).minus(D(v.withheld))
        : D(v.netShares);
      if (net.lte(0)) continue;
      let costUSD = net.times(D(v.fmvUSD));
      let costCAD = costUSD.times(D(v.fx));
      events.push({
        date: v.date, type: 'vest', source: `${g.grantId}`,
        grantIdx: gi, vestIdx: vi,
        sharesDelta: net.toNumber(),
        costUSD: costUSD.toNumber(),
        costCAD: costCAD.toNumber(),
        _decNet: net, _decCostUSD: costUSD, _decCostCAD: costCAD,
      });
    }
  }

  // ── ESPP acquisitions — ACB = FMV on purchase date ──
  for (let [i, e] of esppPurchases.entries()) {
    let shares  = D(e.shares);
    let costUSD = shares.times(D(e.fmvUSD));
    let costCAD = costUSD.times(D(e.fx));
    events.push({
      date: e.date, type: 'espp', source: 'ESPP',
      esppIdx: i,
      sharesDelta: shares.toNumber(),
      costUSD: costUSD.toNumber(),
      costCAD: costCAD.toNumber(),
      _decShares: shares, _decCostUSD: costUSD, _decCostCAD: costCAD,
    });
  }

  // ── DRIP dividend acquisitions ──
  for (let [i, d] of dividends.entries()) {
    if (d.type !== 'drip' || !d.dripShares || !d.dripPriceUSD) continue;
    let shares  = D(d.dripShares);
    let costUSD = shares.times(D(d.dripPriceUSD));
    let costCAD = costUSD.times(D(d.fx));
    events.push({
      date: d.date, type: 'drip', source: 'DRIP Div',
      divIdx: i,
      sharesDelta: shares.toNumber(),
      costUSD: costUSD.toNumber(),
      costCAD: costCAD.toNumber(),
      _decShares: shares, _decCostUSD: costUSD, _decCostCAD: costCAD,
    });
  }

  // ── Sales ──
  for (let [i, s] of sales.entries()) {
    events.push({
      date: s.date, type: 'sale', source: 'Sale',
      saleIdx: i,
      sharesDelta: -D(s.shares).toNumber(),
    });
  }

  // Sort chronologically
  events.sort((a, b) => new Date(a.date) - new Date(b.date));

  // Walk forward — all running totals kept as Decimal
  let runShares = new Decimal(0);
  let runACBusd = new Decimal(0);
  let runACBcad = new Decimal(0);
  let ledger = [];

  for (let ev of events) {
    if (ev.type === 'vest' || ev.type === 'espp' || ev.type === 'drip') {
      runShares = runShares.plus(ev._decNet || ev._decShares);
      runACBusd = runACBusd.plus(ev._decCostUSD);
      runACBcad = runACBcad.plus(ev._decCostCAD);
    } else if (ev.type === 'sale') {
      if (runShares.lte(0)) {
        ev.costUSD = 0; ev.costCAD = 0;
        ev.gainLossUSD = null; ev.gainLossCAD = null;
      } else {
        let s           = sales[ev.saleIdx];
        let soldShares  = new Decimal(String(+s.shares));
        let acbPSusd    = runACBusd.div(runShares);
        let acbPScad    = runACBcad.div(runShares);
        let costUSD     = acbPSusd.times(soldShares);
        let costCAD     = acbPScad.times(soldShares);
        let commission  = new Decimal(String(+s.commissionUSD || 0));
        let proceedsUSD = soldShares.times(new Decimal(String(+s.priceUSD))).minus(commission);
        let proceedsCAD = proceedsUSD.times(new Decimal(String(+s.fx)));
        let glUSD       = proceedsUSD.minus(costUSD);
        let glCAD       = proceedsCAD.minus(costCAD);

        ev.costUSD     = costUSD.toNumber();
        ev.costCAD     = costCAD.toNumber();
        ev.gainLossUSD = glUSD.toNumber();
        ev.gainLossCAD = glCAD.toNumber();
        ev.proceedsUSD = proceedsUSD.toNumber();
        ev.proceedsCAD = proceedsCAD.toNumber();

        runACBusd = runACBusd.minus(costUSD);
        runACBcad = runACBcad.minus(costCAD);
        runShares = runShares.minus(soldShares);
      }
    }
    // Store both Decimal (for precision in downstream calcs) and Number (for display)
    ev.runShares = runShares.toNumber();
    ev.runACBusd = runACBusd.toNumber();
    ev.runACBcad = runACBcad.toNumber();
    ev._decRunShares = runShares;
    ev._decRunACBusd = runACBusd;
    ev._decRunACBcad = runACBcad;
    ledger.push(ev);
  }
  return ledger;
}

// ============================================================
// RENDER ALL
// ============================================================
function renderAll() {
  document.getElementById('dash-year').textContent = currentYear;
  document.getElementById('gl-year').textContent   = currentYear;
  let ledger = buildACBLedger();
  function safe(fn, name) {
    try { fn(); } catch(e) { console.error(name + ' failed:', e.message, e.stack); }
  }
  safe(() => renderDashboard(ledger),  'renderDashboard');
  safe(() => renderOverdueVests(),     'renderOverdueVests');
  safe(() => renderGrants(),           'renderGrants');
  safe(() => renderESPP(),             'renderESPP');
  safe(() => renderDividends(),        'renderDividends');
  safe(() => renderSales(ledger),      'renderSales');
  safe(() => renderGainLoss(ledger),   'renderGainLoss');
  safe(() => renderACBLedger(ledger),  'renderACBLedger');
}

// ============================================================
// OVERDUE VEST NOTIFICATIONS
// ============================================================
function renderOverdueVests() {
  var today = new Date();
  today.setHours(0, 0, 0, 0);
  var overdue = [];

  for (var gi = 0; gi < grants.length; gi++) {
    var g = grants[gi];
    for (var vi = 0; vi < g.vests.length; vi++) {
      var v = g.vests[vi];
      var vestDate = new Date(v.date + 'T00:00:00');
      if (!v.vested && vestDate < today) {
        overdue.push({ grantId: g.grantId, date: v.date });
      }
    }
  }

  // Banner
  var banner = document.getElementById('overdue-banner');
  var badge  = document.getElementById('nav-overdue-badge');

  if (overdue.length === 0) {
    banner.classList.add('hidden');
    banner.innerHTML = '';
    badge.classList.add('hidden');
    badge.textContent = '';
    return;
  }

  // Build banner content
  var noun  = overdue.length === 1 ? 'vest is' : 'vests are';
  banner.innerHTML =
    '<span class="banner-icon">⚠</span>' +
    '<div>' +
      '<p class="banner-title">' + overdue.length + ' unrecorded ' + noun + ' past due</p>' +
      '<button class="banner-link" onclick="switchToGrants()">Go to RSU Grants →</button>' +
    '</div>';
  banner.classList.remove('hidden');

  // Nav badge
  badge.textContent = overdue.length;
  badge.classList.remove('hidden');
}

function switchToGrants() {
  document.querySelectorAll('.nav-btn').forEach(function(b) { b.classList.remove('active'); });
  document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
  document.querySelector('.nav-btn[data-section="grants"]').classList.add('active');
  document.getElementById('section-grants').classList.add('active');
}

// ============================================================
// DASHBOARD
// ============================================================
function renderDashboard(ledger) {
  // Running ACB state at end — use Decimal values where available
  let last = ledger[ledger.length - 1] || { runShares: 0, runACBusd: 0, runACBcad: 0 };
  let lastShares = last._decRunShares || new Decimal(String(last.runShares));
  let lastACBusd = last._decRunACBusd || new Decimal(String(last.runACBusd));
  let lastACBcad = last._decRunACBcad || new Decimal(String(last.runACBcad));

  document.getElementById('dash-shares-held').textContent = fmtN(lastShares.toNumber());
  document.getElementById('dash-acb-cad').textContent     = fmtCAD(lastACBcad.toNumber());
  document.getElementById('dash-acb-usd').textContent     = fmtUSD(lastACBusd.toNumber());

  // Current year gain/loss — accumulate with Decimal
  let yrGL_usd = new Decimal(0);
  let yrGL_cad = new Decimal(0);
  for (let ev of ledger) {
    if (ev.type === 'sale' && ev.gainLossCAD !== null && new Date(ev.date).getFullYear() === currentYear) {
      yrGL_usd = yrGL_usd.plus(new Decimal(String(ev.gainLossUSD)));
      yrGL_cad = yrGL_cad.plus(new Decimal(String(ev.gainLossCAD)));
    }
  }
  let glCADnum = yrGL_cad.toNumber();
  let glUSDnum = yrGL_usd.toNumber();
  let glEl = document.getElementById('dash-gainloss-cad');
  glEl.textContent = fmtSigned(glCADnum, fmtCAD);
  glEl.style.color = glCADnum >= 0 ? '#82e0aa' : '#f1948a';
  document.getElementById('dash-gainloss-usd').textContent = fmtSigned(glUSDnum, fmtUSD);

  // Unvested
  let unvested = 0;
  for (let g of grants) {
    for (let v of g.vests) {
      if (!v.vested) unvested += (+v.grossShares || 0);
    }
  }
  document.getElementById('dash-unvested').textContent = unvested;

  // Upcoming vests
  let upcoming = [];
  let today = new Date();
  for (let g of grants) {
    for (let v of g.vests) {
      if (!v.vested && v.date) {
        let d = new Date(v.date + 'T00:00:00');
        if (d >= today) upcoming.push({ grantId: g.grantId, date: v.date, qty: v.grossShares });
      }
    }
  }
  upcoming.sort((a, b) => new Date(a.date) - new Date(b.date));
  let ub = document.getElementById('dash-upcoming-body');
  ub.innerHTML = '';
  upcoming.slice(0, 8).forEach(u => {
    let tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.grantId}</td><td>${u.date}</td><td>${u.qty}</td>`;
    ub.appendChild(tr);
  });
  if (upcoming.length === 0) ub.innerHTML = '<tr><td colspan="3" class="muted">No upcoming vests</td></tr>';

  // Holdings by grant
  let hb   = document.getElementById('dash-holdings-body');
  let hft  = document.getElementById('dash-holdings-foot');
  hb.innerHTML = '';
  let totReceived = 0, totSold = 0, totRemaining = 0, totACBusd = 0, totACBcad = 0;

  if (lastShares.gt(0)) {
    let acbPScad = lastACBcad.div(lastShares).toNumber();
    let acbPSusd = lastACBusd.div(lastShares).toNumber();

    for (let g of grants) {
      // Shares received = sum of net shares across vested periods
      let received = 0;
      for (let v of g.vests) {
        if (v.vested && v.netShares) received += +v.netShares;
      }
      if (received <= 0) continue;

      // Shares sold = from sales breakdown referencing this grant
      let soldQty = sales.reduce((sum, s) => {
        if (s.breakdown && s.breakdown.length > 0) {
          return sum + s.breakdown
            .filter(b => (b.sourceType === 'rsu' || !b.sourceType) && (b.sourceId === g.grantId || b.grantId === g.grantId))
            .reduce((a, b) => a + (+b.shares || 0), 0);
        }
        if (s.grantId === g.grantId) return sum + +s.shares;
        return sum;
      }, 0);

      let remaining = Math.max(0, received - soldQty);
      let dRemaining = new Decimal(String(remaining));
      let dAcbPSusd  = new Decimal(String(acbPSusd));
      let dAcbPScad  = new Decimal(String(acbPScad));
      let acbUSDrem  = dRemaining.times(dAcbPSusd).toNumber();
      let acbCADrem  = dRemaining.times(dAcbPScad).toNumber();

      totReceived += received;
      totSold     += soldQty;
      totRemaining = new Decimal(String(totRemaining)).plus(dRemaining).toNumber();
      totACBusd    = new Decimal(String(totACBusd)).plus(new Decimal(String(acbUSDrem))).toNumber();
      totACBcad    = new Decimal(String(totACBcad)).plus(new Decimal(String(acbCADrem))).toNumber();

      if (remaining <= 0) continue;

      let soldCell = soldQty > 0 ? '<span class="loss">' + fmtN(soldQty) + '</span>' : '0';
      let remCell  = '<span class="gain">' + fmtN(remaining) + '</span>';
      let tr = document.createElement('tr');
      tr.innerHTML = '<td>' + g.grantId + '</td>' +
        '<td>' + fmtN(received) + '</td>' +
        '<td>' + soldCell + '</td>' +
        '<td>' + remCell + '</td>' +
        '<td>' + fmtUSD(acbPSusd) + '</td><td>' + fmtUSD(acbUSDrem) + '</td>' +
        '<td>' + fmtCAD(acbPScad) + '</td><td>' + fmtCAD(acbCADrem) + '</td>';
      hb.appendChild(tr);
    }
  }

  if (!hb.innerHTML) {
    hb.innerHTML = '<tr><td colspan="8" class="muted">No shares currently held</td></tr>';
    if (hft) hft.innerHTML = '';
  } else if (hft) {
    hft.innerHTML = `<tr>
      <td><strong>Total</strong></td>
      <td>${fmtN(totReceived)}</td>
      <td>${totSold > 0 ? '<span class="loss">' + fmtN(totSold) + '</span>' : '0'}</td>
      <td>${totRemaining > 0 ? '<span class="gain">' + fmtN(totRemaining) + '</span>' : '0'}</td>
      <td></td><td>${fmtUSD(totACBusd)}</td>
      <td></td><td>${fmtCAD(totACBcad)}</td>
    </tr>`;
  }

  // ── ESPP Holdings table ──
  var eb  = document.getElementById('dash-espp-body');
  var eft = document.getElementById('dash-espp-foot');
  eb.innerHTML = '';
  var eTotPurch = 0, eTotSold = 0, eTotRem = 0, eTotACBusd = 0, eTotACBcad = 0;

  if (esppPurchases.length === 0) {
    eb.innerHTML = '<tr><td colspan="8" class="muted">No ESPP purchases recorded</td></tr>';
    if (eft) eft.innerHTML = '';
  } else {
    var acbPScad = lastShares.gt(0) ? lastACBcad.div(lastShares).toNumber() : 0;
    var acbPSusd = lastShares.gt(0) ? lastACBusd.div(lastShares).toNumber() : 0;

    for (var ei = 0; ei < esppPurchases.length; ei++) {
      var ep = esppPurchases[ei];
      var epShares = +ep.shares || 0;

      // Use same calculation as ESPP tab — index-based key 'espp-N'
      var epSold = calcEsppSoldFromSales(ei);

      var epRem    = Math.max(0, epShares - epSold);
      var epACBusd = epRem * acbPSusd;
      var epACBcad = epRem * acbPScad;

      eTotPurch += epShares;
      eTotSold  += epSold;
      eTotRem   += epRem;
      eTotACBusd+= epACBusd;
      eTotACBcad+= epACBcad;

      if (epRem <= 0) continue;

      var soldCell = epSold > 0 ? '<span class="loss">' + fmtN(epSold) + '</span>' : '0';
      var remCell  = '<span class="gain">' + fmtN(epRem) + '</span>';
      var etr = document.createElement('tr');
      etr.innerHTML =
        '<td>' + ep.date + '</td>' +
        '<td>' + fmtN(epShares) + '</td>' +
        '<td>' + soldCell + '</td>' +
        '<td>' + remCell  + '</td>' +
        '<td>' + fmtUSD(acbPSusd) + '</td><td>' + fmtUSD(epACBusd) + '</td>' +
        '<td>' + fmtCAD(acbPScad) + '</td><td>' + fmtCAD(epACBcad) + '</td>';
      eb.appendChild(etr);
    }

    if (eft) {
      eft.innerHTML = '<tr>' +
        '<td><strong>Total</strong></td>' +
        '<td>' + fmtN(eTotPurch) + '</td>' +
        '<td>' + (eTotSold > 0 ? '<span class="loss">' + fmtN(eTotSold) + '</span>' : '0') + '</td>' +
        '<td>' + (eTotRem  > 0 ? '<span class="gain">' + fmtN(eTotRem)  + '</span>' : '0') + '</td>' +
        '<td></td><td>' + fmtUSD(eTotACBusd) + '</td>' +
        '<td></td><td>' + fmtCAD(eTotACBcad) + '</td>' +
        '</tr>';
    }
  }
}

// ============================================================
// GRANTS SECTION
// ============================================================
document.getElementById('btn-add-grant').addEventListener('click', () => {
  editingGrantIdx = null;
  document.getElementById('gf-grant-date').value = '';
  document.getElementById('gf-grant-id').value   = '';
  document.getElementById('gf-total-shares').value = '';
  document.getElementById('gf-notes').value = '';
  document.getElementById('vest-rows-container').innerHTML = '';
  document.getElementById('chk-prepopulate').checked = false;
  document.getElementById('grant-form-title').textContent = 'New RSU Grant';
  document.getElementById('grant-form').classList.remove('hidden');
  document.getElementById('vest-schedule-area').classList.remove('hidden');
});
document.getElementById('btn-cancel-grant').addEventListener('click', () => {
  document.getElementById('grant-form').classList.add('hidden');
});
document.getElementById('btn-add-vest-row').addEventListener('click', () => {
  addVestInputRow();
});

// ── Prepopulate 13 vest dates ──
function calcVestDates(grantDateStr) {
  // Pattern from grant date: P1 = July 1 of following year, then Oct 1, Dec 31, Apr 1 repeating
  if (!grantDateStr) return [];
  let grant = new Date(grantDateStr + 'T00:00:00');
  let year  = grant.getFullYear() + 1; // first vest is year after grant

  // The quarterly pattern: Jul 1, Oct 1, Dec 31, Apr 1 — then repeats next year
  const slots = [
    { m: 7,  d: 1  },
    { m: 10, d: 1  },
    { m: 12, d: 31 },
    { m: 4,  d: 1  },
  ];

  let dates = [];
  let slotIdx = 0;
  let y = year;

  for (let i = 0; i < 13; i++) {
    let slot = slots[slotIdx];
    // Apr 1 belongs to the *next* year relative to the Jul/Oct/Dec group
    // We track year separately: after Dec 31 slot, increment year for Apr 1
    let mm = String(slot.m).padStart(2, '0');
    let dd = String(slot.d).padStart(2, '0');
    dates.push(`${y}-${mm}-${dd}`);

    // Advance slot and year
    slotIdx++;
    if (slotIdx === 4) {
      slotIdx = 0;
      y++;  // next full cycle starts a year later
    } else if (slotIdx === 3) {
      // Apr 1 is in the year AFTER the preceding Jul/Oct/Dec
      y++;
    }
    // After Apr 1 (slotIdx just became 0 after reset), year was already incremented
    // We need to correct: the Jul that follows Apr is same year as Apr
    // Rebuild: track year by cycle position cleanly below
  }

  // Cleaner approach: generate directly by cycle
  dates = [];
  // Cycle: [Jul y, Oct y, Dec y, Apr y+1] repeating
  // P1=Jul y1, P2=Oct y1, P3=Dec y1, P4=Apr y2, P5=Jul y2, P6=Oct y2, P7=Dec y2, P8=Apr y3 ...
  for (let i = 0; i < 13; i++) {
    let cyclePos = i % 4; // 0=Jul, 1=Oct, 2=Dec, 3=Apr
    let cycleNum = Math.floor(i / 4); // which cycle (0-based)
    let y2 = year + cycleNum;
    let slot2;
    if      (cyclePos === 0) slot2 = { y: y2,     m: 7,  d: 1  };
    else if (cyclePos === 1) slot2 = { y: y2,     m: 10, d: 1  };
    else if (cyclePos === 2) slot2 = { y: y2,     m: 12, d: 31 };
    else                     slot2 = { y: y2 + 1, m: 4,  d: 1  };
    let mm2 = String(slot2.m).padStart(2, '0');
    let dd2 = String(slot2.d).padStart(2, '0');
    dates.push(`${slot2.y}-${mm2}-${dd2}`);
  }
  return dates;
}

document.getElementById('chk-prepopulate').addEventListener('change', function() {
  if (!this.checked) return;
  let grantDate = document.getElementById('gf-grant-date').value;
  if (!grantDate) {
    alert('Please enter a Grant Date first.');
    this.checked = false;
    return;
  }
  let c = document.getElementById('vest-rows-container');
  if (c.children.length > 0) {
    if (!confirm('This will replace any vest rows already entered. Proceed?')) {
      this.checked = false;
      return;
    }
  }
  c.innerHTML = '';
  let dates = calcVestDates(grantDate);
  dates.forEach(d => addVestInputRow({ date: d, grossShares: '', withheld: '' }));
  // Uncheck so it can be triggered again if grant date changes
  this.checked = false;
});

function addVestInputRow(vest = null) {
  let c = document.getElementById('vest-rows-container');
  let idx = c.children.length;
  let div = document.createElement('div');
  div.className = 'vest-row-input';
  div.innerHTML = `
    <div class="form-field">
      ${idx === 0 ? '<label>Vest Date</label>' : ''}
      <input type="date" class="vr-date" value="${vest ? vest.date : ''}">
    </div>
    <div class="form-field">
      ${idx === 0 ? '<label>Grant Quantity</label>' : ''}
      <input type="number" class="vr-shares" placeholder="e.g. 23" value="${vest ? vest.grossShares : ''}">
    </div>
    <button class="btn-remove-vest-row" onclick="this.parentElement.remove()">✕</button>`;
  c.appendChild(div);
}

document.getElementById('btn-save-grant').addEventListener('click', () => {
  try {
    let grantDate   = document.getElementById('gf-grant-date').value;
    let grantId     = document.getElementById('gf-grant-id').value.trim();
    let totalShares = parseFloat(document.getElementById('gf-total-shares').value);
    let notes       = document.getElementById('gf-notes').value.trim();
    if (!grantDate || !grantId || isNaN(totalShares)) {
      alert('Please fill in Grant Date, Grant ID, and Total Shares.'); return;
    }

    // Read vest rows
    let vests = [];
    document.querySelectorAll('#vest-rows-container .vest-row-input').forEach(row => {
      let dateEl   = row.querySelector('.vr-date');
      let sharesEl = row.querySelector('.vr-shares');
      if (!dateEl || !sharesEl) return;
      let date   = dateEl.value;
      let shares = parseFloat(sharesEl.value) || 0;
      if (date) {
        vests.push({ date, grossShares: shares, withheld: 0, netShares: shares, vested: false, fmvUSD: '', fmvTotalUSD: '', fx: '' });
      }
    });

    let isEditing = editingGrantIdx !== null;

    if (isEditing) {
      // Preserve existing vest details (fmv, fx, vested flag, withheld)
      let existing = grants[editingGrantIdx].vests || [];
      vests = vests.map((v, i) => {
        let ex = existing[i] || {};
        return {
          date: v.date,
          grossShares: v.grossShares,
          withheld: ex.withheld || 0,
          netShares: v.grossShares - (ex.withheld || 0),
          vested: ex.vested || false,
          fmvUSD: ex.fmvUSD || '',
          fmvTotalUSD: ex.fmvTotalUSD || '',
          fx: ex.fx || '',
          notes: ex.notes || ''
        };
      });
      grants[editingGrantIdx] = { ...grants[editingGrantIdx], grantDate, grantId, totalShares, notes, vests };
    } else {
      grants.push({ id: uid(), grantDate, grantId, totalShares, notes, vests });
    }

    editingGrantIdx = null;
    saveData(); renderAll();
    document.getElementById('grant-form').classList.add('hidden');
    showToast(isEditing ? 'Grant updated.' : 'Grant saved.');
  } catch(err) {
    console.error('Save grant error:', err);
    alert('An error occurred saving the grant. Check the browser console for details.');
  }
});

function renderGrants() {
  // Remember which grants are currently open so we can restore after re-render
  let openStates = {};
  grants.forEach((g, gi) => {
    let body = document.getElementById(`grant-body-${gi}`);
    if (body) openStates[gi] = body.classList.contains('open');
  });

  let list = document.getElementById('grants-list');
  list.innerHTML = '';
  if (grants.length === 0) {
    list.innerHTML = '<p class="hint" style="padding:20px">No grants yet. Click "+ New Grant" to add your first RSU batch.</p>';
    return;
  }
  grants.forEach((g, gi) => {
    let totalVested = g.vests.filter(v => v.vested).reduce((s, v) => s + (+v.grossShares||0), 0);
    let totalNet    = g.vests.filter(v => v.vested).reduce((s, v) => s + (+v.netShares||0), 0);
    let totalFuture = g.vests.filter(v => !v.vested).reduce((s, v) => s + (+v.grossShares||0), 0);

    let div = document.createElement('div');
    div.className = 'grant-card';
    div.innerHTML = `
      <div class="grant-card-header" onclick="toggleGrant(${gi})">
        <div class="grant-meta">
          <span class="grant-id">${g.grantId}</span>
          <span class="grant-tag">Granted <strong>${g.grantDate}</strong></span>
          <span class="grant-tag">Total <strong>${g.totalShares}</strong> shares</span>
          <span class="grant-tag">Vested <strong>${totalVested}</strong> gross / <strong>${fmtN(totalNet)}</strong> net</span>
          <span class="grant-tag">Unvested <strong>${totalFuture}</strong></span>
          ${g.notes ? `<span class="grant-tag">${g.notes}</span>` : ''}
        </div>
        <div style="display:flex;align-items:center;gap:10px">
          <div class="grant-actions" onclick="event.stopPropagation()">
            <button class="btn-sm btn-edit-sm" onclick="editGrant(${gi})">Edit</button>
            <button class="btn-sm btn-del-sm"  onclick="deleteGrant(${gi})">Delete</button>
          </div>
          <span class="grant-chevron" id="chevron-${gi}">▶</span>
        </div>
      </div>
      <div class="grant-body" id="grant-body-${gi}">
        ${renderVestTable(g, gi)}
      </div>`;
    list.appendChild(div);

    // Restore open state if it was open before re-render
    if (openStates[gi]) {
      document.getElementById(`grant-body-${gi}`).classList.add('open');
      document.getElementById(`chevron-${gi}`).classList.add('open');
    }
  });
}

function toggleGrant(gi) {
  let body    = document.getElementById(`grant-body-${gi}`);
  let chevron = document.getElementById(`chevron-${gi}`);
  body.classList.toggle('open');
  chevron.classList.toggle('open');
}

function renderVestTable(g, gi) {
  let totGrantQty = 0, totVested = 0, totFmvSoldTax = new Decimal(0), totSoldTax = 0, totNet = new Decimal(0);
  let totCostUSD = new Decimal(0), totCostCAD = new Decimal(0), totSold = 0, totRemaining = new Decimal(0);

  // Calculate shares sold per vest row — supports new breakdown[] and legacy grantId/vestDate
  let soldByVest = {};
  for (let s of sales) {
    if (s.breakdown && s.breakdown.length > 0) {
      for (let b of s.breakdown) {
        if (b.sourceType === 'rsu' && b.sourceId === g.grantId && b.vestDate) {
          soldByVest[b.vestDate] = (soldByVest[b.vestDate] || 0) + (+b.shares || 0);
        }
        // Legacy breakdown format
        if (!b.sourceType && b.grantId === g.grantId && b.vestDate) {
          soldByVest[b.vestDate] = (soldByVest[b.vestDate] || 0) + (+b.shares || 0);
        }
      }
    } else if (s.grantId === g.grantId && s.vestDate) {
      soldByVest[s.vestDate] = (soldByVest[s.vestDate] || 0) + (+s.shares || 0);
    }
  }

  let rows = g.vests.map((v, vi) => {
    let period = vi + 1;
    let isVested = v.vested && v.fmvUSD;
    let dNet       = v.netShares !== undefined
      ? new Decimal(String(+v.netShares))
      : new Decimal(String(+v.grossShares)).minus(new Decimal(String(+v.withheld || 0)));
    let net        = dNet.toNumber();
    let dFmvPS     = new Decimal(String(+v.fmvUSD || 0));
    let dFx        = new Decimal(String(+v.fx || 0));
    let dWithheld  = new Decimal(String(+v.withheld || 0));
    let dGross     = new Decimal(String(+v.grossShares || 0));
    let fmvTotal   = v.fmvTotalUSD || (v.fmvUSD ? dGross.times(dFmvPS).toNumber() : 0);
    let withheld   = dWithheld.toNumber();
    let fmvSoldTax = isVested ? dWithheld.times(dFmvPS).toNumber() : 0;
    let costUSD    = isVested ? dNet.times(dFmvPS).toNumber() : 0;
    let costCAD    = isVested ? new Decimal(String(costUSD)).times(dFx).toNumber() : 0;
    let costPSUSD  = isVested && net > 0 ? new Decimal(String(costUSD)).div(dNet).toNumber() : 0;
    let costPSCAD  = isVested && net > 0 ? new Decimal(String(costCAD)).div(dNet).toNumber() : 0;
    let soldQty    = soldByVest[v.date] || 0;
    let remaining  = isVested ? Math.max(0, net - soldQty) : null;

    let today = new Date(); today.setHours(0,0,0,0);
    let vestDate = new Date(v.date + 'T00:00:00');
    let isOverdue = !v.vested && vestDate < today;

    let tag = isVested
      ? `<span class="tag tag-vested">Vested</span>`
      : isOverdue
        ? `<span class="tag tag-overdue">Overdue</span>`
        : `<span class="tag tag-future">Future</span>`;
    let m = '<span class="muted">–</span>';
    let fxCell        = v.fx      ? parseFloat(v.fx).toFixed(4) : m;
    let fmvTotalCell  = isVested && fmvTotal   ? fmtUSD(fmvTotal)   : m;
    let fmvPSCell     = isVested && v.fmvUSD   ? fmtUSD(v.fmvUSD)   : m;
    let fmvSoldCell   = isVested && withheld   ? fmtUSD(fmvSoldTax) : (isVested ? '—' : m);
    let costUSDCell   = isVested ? fmtUSD(costUSD)   : m;
    let costCADCell   = isVested ? fmtCAD(costCAD)   : m;
    let costPSUSDCell = isVested && net > 0 ? fmtUSD(costPSUSD) : m;
    let costPSCADCell = isVested && net > 0 ? fmtCAD(costPSCAD) : m;
    let soldCell      = isVested ? (soldQty > 0 ? `<span class="loss">${soldQty}</span>` : '0') : m;
    let remainCell    = isVested ? (remaining === 0 ? '<span class="muted">0</span>' : `<span class="gain">${fmtN(remaining)}</span>`) : m;
    let rowCls = isVested ? 'vested-row' : isOverdue ? 'vest-overdue-row' : 'future-row';

    totGrantQty  += +v.grossShares || 0;
    if (isVested) {
      totVested    += +v.grossShares || 0;
      totSoldTax   += withheld;
      totFmvSoldTax = totFmvSoldTax.plus(new Decimal(String(fmvSoldTax)));
      totNet        = totNet.plus(dNet);
      totCostUSD    = totCostUSD.plus(new Decimal(String(costUSD)));
      totCostCAD    = totCostCAD.plus(new Decimal(String(costCAD)));
      totSold      += soldQty;
      totRemaining  = totRemaining.plus(new Decimal(String(remaining || 0)));
    }

    return `<tr class="${rowCls}">
      <td style="color:#7f8c8d;font-weight:bold">P${period}</td>
      <td>${v.date}</td>
      <td>${v.grossShares}</td>
      <td>${tag}</td>
      <td>${isVested ? fmtN(+v.grossShares) : m}</td>
      <td>${fmvTotalCell}</td>
      <td>${fmvPSCell}</td>
      <td>${isVested ? fmtN(withheld) : m}</td>
      <td>${fmvSoldCell}</td>
      <td>${isVested ? fmtN(net) : m}</td>
      <td>${fxCell}</td>
      <td>${costUSDCell}</td>
      <td>${costPSUSDCell}</td>
      <td>${costCADCell}</td>
      <td>${costPSCADCell}</td>
      <td>${soldCell}</td>
      <td>${remainCell}</td>
      <td><button class="btn-vest-sm" onclick="openVestModal(${gi},${vi})">
        ${isVested ? 'Edit' : 'Record Vest'}
      </button></td>
    </tr>`;
  }).join('');

  let totalsRow = `<tr>
    <td></td>
    <td><strong>Total</strong></td>
    <td><strong>${totGrantQty}</strong></td>
    <td></td>
    <td><strong>${totVested}</strong></td>
    <td></td><td></td>
    <td><strong>${fmtN(totSoldTax)}</strong></td>
    <td><strong>${totFmvSoldTax.gt(0) ? fmtUSD(totFmvSoldTax.toNumber()) : '–'}</strong></td>
    <td><strong>${fmtN(totNet.toNumber())}</strong></td>
    <td></td>
    <td><strong>${totCostUSD.gt(0) ? fmtUSD(totCostUSD.toNumber()) : '–'}</strong></td>
    <td></td>
    <td><strong>${totCostCAD.gt(0) ? fmtCAD(totCostCAD.toNumber()) : '–'}</strong></td>
    <td></td>
    <td><strong>${totSold > 0 ? totSold : '0'}</strong></td>
    <td><strong>${fmtN(totRemaining.toNumber())}</strong></td>
    <td></td>
  </tr>`;

  return `<div class="table-scroll">
    <table>
      <thead><tr>
        <th>Period</th><th>Vest Date</th><th>Grant Qty</th><th>Status</th>
        <th>Vested</th>
        <th>FMV Total (USD)</th><th>FMV/Share (USD)</th>
        <th>Shares Sold for Taxes</th><th>FMV of Shares Sold for Taxes (USD)</th>
        <th>Net Received</th><th>FX Rate</th>
        <th>Cost (USD)</th><th>Cost/Share (USD)</th>
        <th>Cost (CAD)</th><th>Cost/Share (CAD)</th>
        <th>Sold</th><th>Remaining</th>
        <th>Action</th>
      </tr></thead>
      <tbody>${rows || '<tr><td colspan="18" class="muted">No vest schedule yet.</td></tr>'}</tbody>
      <tfoot>${totalsRow}</tfoot>
    </table>
  </div>`;
}

function editGrant(gi) {
  let g = grants[gi];
  editingGrantIdx = gi;
  document.getElementById('gf-grant-date').value   = g.grantDate;
  document.getElementById('gf-grant-id').value     = g.grantId;
  document.getElementById('gf-total-shares').value = g.totalShares;
  document.getElementById('gf-notes').value        = g.notes || '';
  let c = document.getElementById('vest-rows-container');
  c.innerHTML = '';
  g.vests.forEach(v => addVestInputRow(v));
  document.getElementById('chk-prepopulate').checked = false;
  document.getElementById('grant-form-title').textContent = 'Edit Grant';
  document.getElementById('grant-form').classList.remove('hidden');
  document.getElementById('vest-schedule-area').classList.remove('hidden');
  document.getElementById('grant-form').scrollIntoView({ behavior: 'smooth' });
}

function deleteGrant(gi) {
  showModal('Delete Grant', `Delete grant "${grants[gi].grantId}"? All vest data will be lost.`, () => {
    grants.splice(gi, 1); saveData(); renderAll();
  });
}

// ============================================================
// VEST MODAL
// ============================================================
function openVestModal(gi, vi) {
  editingVestInfo = { gi, vi };
  let v = grants[gi].vests[vi];
  document.getElementById('vm-date').value     = v.date;
  document.getElementById('vm-gross').value    = v.grossShares;
  document.getElementById('vm-withheld').value = v.withheld || '';
  // Show total FMV (gross * fmvPerShare) if already recorded
  document.getElementById('vm-fmv').value = (v.fmvUSD && v.grossShares) ? (+v.fmvUSD * +v.grossShares).toFixed(4) : '';
  document.getElementById('vm-fx').value       = v.fx      || '';
  document.getElementById('vm-preview').innerHTML = '';
  document.getElementById('vm-fx-display').textContent = '';
  document.getElementById('vm-fmv-per-share').textContent = '';
  document.getElementById('vest-modal-overlay').classList.remove('hidden');
  if (v.date) fetchFX(v.date, document.getElementById('vm-fx-display'), document.getElementById('vm-fx'));
  updateVestPreview();
}

document.getElementById('btn-cancel-vest').addEventListener('click', () => {
  document.getElementById('vest-modal-overlay').classList.add('hidden');
  editingVestInfo = null;
});

['vm-gross','vm-withheld','vm-fmv','vm-fx'].forEach(id =>
  document.getElementById(id).addEventListener('input', updateVestPreview));

function updateVestPreview() {
  let gross    = parseFloat(document.getElementById('vm-gross').value) || 0;
  let with_    = parseFloat(document.getElementById('vm-withheld').value) || 0;
  let fmvTotal = parseFloat(document.getElementById('vm-fmv').value);
  let fx       = parseFloat(document.getElementById('vm-fx').value);
  let prev     = document.getElementById('vm-preview');
  let perShareEl = document.getElementById('vm-fmv-per-share');

  if (fmvTotal && gross > 0) {
    let fps = new Decimal(String(fmvTotal)).div(new Decimal(String(gross)));
    perShareEl.textContent = `= ${fmtUSD(fps.toNumber())} per share`;
  } else {
    perShareEl.textContent = '';
  }

  if (!fmvTotal || !fx || !gross) { prev.innerHTML = ''; return; }
  let dGross      = new Decimal(String(gross));
  let dWith       = new Decimal(String(with_));
  let dFmvTotal   = new Decimal(String(fmvTotal));
  let dFx         = new Decimal(String(fx));
  let dNet        = dGross.minus(dWith);
  let dFmvPerShare= dFmvTotal.div(dGross);
  let dCostUSD    = dNet.times(dFmvPerShare);
  let dCostCAD    = dCostUSD.times(dFx);
  let dCostPSCAD  = dNet.gt(0) ? dCostCAD.div(dNet) : new Decimal(0);
  prev.innerHTML = `
    <div class="preview-item"><span class="preview-label">FMV / Share (USD)</span><span class="preview-value">${fmtUSD(dFmvPerShare.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Net Shares Received</span><span class="preview-value">${fmtN(dNet.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Cost (USD)</span><span class="preview-value">${fmtUSD(dCostUSD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Cost (CAD)</span><span class="preview-value">${fmtCAD(dCostCAD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Cost/Share (CAD)</span><span class="preview-value">${fmtCAD(dCostPSCAD.toNumber())}</span></div>`;
}

function saveVestAndClose(openNext) {
  if (!editingVestInfo) return;
  let { gi, vi } = editingVestInfo;
  let date     = document.getElementById('vm-date').value;
  let gross    = parseFloat(document.getElementById('vm-gross').value);
  let with_    = parseFloat(document.getElementById('vm-withheld').value) || 0;
  let fmvTotal = parseFloat(document.getElementById('vm-fmv').value);
  let fx       = parseFloat(document.getElementById('vm-fx').value);
  if (!date || isNaN(gross) || isNaN(fmvTotal) || isNaN(fx)) {
    alert('Please fill in Date, Gross Shares, Total FMV, and FX Rate.'); return;
  }
  let fmvPerShare = fmvTotal / gross;
  grants[gi].vests[vi] = {
    date, grossShares: gross, withheld: with_,
    netShares: gross - with_,
    fmvUSD: fmvPerShare, fmvTotalUSD: fmvTotal, fx, vested: true
  };
  saveData(); renderAll();
  showToast('Vest recorded.');

  if (openNext) {
    // Find the next vest row in the same grant (skip already-vested ones)
    let vests = grants[gi].vests;
    let nextVi = null;
    for (let i = vi + 1; i < vests.length; i++) {
      if (!vests[i].vested) { nextVi = i; break; }
    }
    if (nextVi !== null) {
      editingVestInfo = null;
      openVestModal(gi, nextVi);
    } else {
      // No more unvested rows in this grant
      document.getElementById('vest-modal-overlay').classList.add('hidden');
      editingVestInfo = null;
      showToast('All vest periods recorded for this grant.');
    }
  } else {
    document.getElementById('vest-modal-overlay').classList.add('hidden');
    editingVestInfo = null;
  }
}

document.getElementById('btn-save-vest').addEventListener('click', () => saveVestAndClose(false));
document.getElementById('btn-save-next-vest').addEventListener('click', () => saveVestAndClose(true));

// ============================================================
// ESPP SECTION
// ============================================================
document.getElementById('btn-add-espp').addEventListener('click', () => {
  editingEsppIdx = null;
  ['ef-date','ef-shares','ef-purchase-price','ef-fmv','ef-fx','ef-fx-cad','ef-notes'].forEach(id =>
    document.getElementById(id).value = '');
  document.getElementById('ef-preview').innerHTML = '';
  document.getElementById('ef-fx-display').textContent = '';
  document.getElementById('ef-fx-cad-display').textContent = '';
  document.getElementById('espp-form').classList.remove('hidden');
});
document.getElementById('btn-cancel-espp').addEventListener('click', () => {
  document.getElementById('espp-form').classList.add('hidden');
  editingEsppIdx = null;
});

['ef-shares','ef-purchase-price','ef-fmv'].forEach(id =>
  document.getElementById(id).addEventListener('input', updateEsppPreview));

function updateEsppPreview() {
  let shares   = parseFloat(document.getElementById('ef-shares').value) || 0;
  let purPrice = parseFloat(document.getElementById('ef-purchase-price').value);
  let fmv      = parseFloat(document.getElementById('ef-fmv').value);
  let fx       = parseFloat(document.getElementById('ef-fx').value);
  let prev     = document.getElementById('ef-preview');
  if (!purPrice || !fmv || !fx) { prev.innerHTML = ''; return; }
  let dShares  = new Decimal(String(shares));
  let dPur     = new Decimal(String(purPrice));
  let dFmv     = new Decimal(String(fmv));
  let dFx      = new Decimal(String(fx));
  let dPurUSD  = dShares.times(dPur);
  let dPurCAD  = dPurUSD.times(dFx);
  let dFmvUSD  = dShares.times(dFmv);
  let dFmvCAD  = dFmvUSD.times(dFx);
  let dBenUSD  = dFmvUSD.minus(dPurUSD);
  let dBenCAD  = dFmvCAD.minus(dPurCAD);
  let dAcbPSCAD= dFmv.times(dFx);
  prev.innerHTML = `
    <div class="preview-item"><span class="preview-label">Purchase Cost (USD)</span><span class="preview-value">${fmtUSD(dPurUSD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Purchase Cost (CAD)</span><span class="preview-value">${fmtCAD(dPurCAD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">FMV on Purchase (USD)</span><span class="preview-value">${fmtUSD(dFmvUSD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">FMV on Purchase (CAD)</span><span class="preview-value">${fmtCAD(dFmvCAD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Taxable Benefit (USD)</span><span class="preview-value">${fmtUSD(dBenUSD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">Taxable Benefit (CAD)</span><span class="preview-value">${fmtCAD(dBenCAD.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">ACB/Share (USD)</span><span class="preview-value">${fmtUSD(dFmv.toNumber())}</span></div>
    <div class="preview-item"><span class="preview-label">ACB/Share (CAD)</span><span class="preview-value">${fmtCAD(dAcbPSCAD.toNumber())}</span></div>`;
}

document.getElementById('btn-save-espp').addEventListener('click', () => {
  let date          = document.getElementById('ef-date').value;
  let shares        = parseFloat(document.getElementById('ef-shares').value);
  let purchasePrice = parseFloat(document.getElementById('ef-purchase-price').value);
  let fmv           = parseFloat(document.getElementById('ef-fmv').value);
  let fx            = parseFloat(document.getElementById('ef-fx').value);
  let fxCad         = parseFloat(document.getElementById('ef-fx-cad').value) || (fx ? parseFloat((1/fx).toFixed(6)) : 0);
  let notes         = document.getElementById('ef-notes').value.trim();
  if (!date || isNaN(shares) || isNaN(purchasePrice) || isNaN(fmv) || isNaN(fx)) {
    alert('Please fill in all required fields.'); return;
  }
  let rec = { id: uid(), date, shares, purchasePriceUSD: purchasePrice, fmvUSD: fmv, fx, fxCad, notes };
  if (editingEsppIdx !== null) { esppPurchases[editingEsppIdx] = { ...esppPurchases[editingEsppIdx], ...rec }; }
  else { esppPurchases.push(rec); }
  saveData(); renderAll();
  document.getElementById('espp-form').classList.add('hidden');
  editingEsppIdx = null;
  showToast('ESPP purchase saved.');
});

function renderESPP() {
  let tbody = document.getElementById('espp-body');
  let tfoot = document.getElementById('espp-foot');
  tbody.innerHTML = '';
  let totPurUSD = new Decimal(0), totPurCAD = new Decimal(0);
  let totFmvUSD = new Decimal(0), totFmvCAD = new Decimal(0);
  let totBenUSD = new Decimal(0), totBenCAD = new Decimal(0);
  let totShares = 0, totSold = 0;

  esppPurchases.forEach((e, i) => {
    let dShares   = new Decimal(String(+e.shares));
    let dPurPrice = new Decimal(String(+e.purchasePriceUSD));
    let dFmvPS    = new Decimal(String(+e.fmvUSD));
    let dFx       = new Decimal(String(+e.fx));
    let dPurUSD   = dShares.times(dPurPrice);
    let dPurCAD   = dPurUSD.times(dFx);
    let dFmvUSD   = dShares.times(dFmvPS);
    let dFmvCAD   = dFmvUSD.times(dFx);
    let dBenUSD   = dFmvUSD.minus(dPurUSD);
    let dBenCAD   = dFmvCAD.minus(dPurCAD);
    let dAcbPSCAD = dFmvPS.times(dFx);
    let fxCad     = e.fxCad || parseFloat((1 / +e.fx).toFixed(6));
    let sharesSold = calcEsppSoldFromSales(i);
    let remaining  = Math.max(0, +e.shares - sharesSold);

    totPurUSD = totPurUSD.plus(dPurUSD);
    totPurCAD = totPurCAD.plus(dPurCAD);
    totFmvUSD = totFmvUSD.plus(dFmvUSD);
    totFmvCAD = totFmvCAD.plus(dFmvCAD);
    totBenUSD = totBenUSD.plus(dBenUSD);
    totBenCAD = totBenCAD.plus(dBenCAD);
    totShares += +e.shares; totSold += sharesSold;

    let tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${e.date}</td>
      <td>${e.shares}</td>
      <td>${fmtUSD(e.purchasePriceUSD)}</td>
      <td>${fmtUSD(e.fmvUSD)}</td>
      <td>${parseFloat(e.fx).toFixed(4)}</td>
      <td>${fxCad.toFixed(6)}</td>
      <td>${fmtUSD(dPurUSD.toNumber())}</td><td>${fmtCAD(dPurCAD.toNumber())}</td>
      <td>${fmtUSD(dFmvUSD.toNumber())}</td><td>${fmtCAD(dFmvCAD.toNumber())}</td>
      <td class="gain">${fmtUSD(dBenUSD.toNumber())}</td><td class="gain">${fmtCAD(dBenCAD.toNumber())}</td>
      <td>${fmtUSD(dFmvPS.toNumber())}</td><td>${fmtCAD(dAcbPSCAD.toNumber())}</td>
      <td>${sharesSold > 0 ? `<span class="loss">${sharesSold}</span>` : '0'}</td>
      <td>${remaining > 0 ? `<span class="gain">${fmtN(remaining)}</span>` : '<span class="muted">0</span>'}</td>
      <td>${e.notes||'—'}</td>
      <td>
        <button class="btn-sm btn-edit-sm" onclick="editESPP(${i})">Edit</button>
        <button class="btn-sm btn-del-sm"  onclick="deleteESPP(${i})">Del</button>
      </td>`;
    tbody.appendChild(tr);
  });

  if (!esppPurchases.length) {
    tbody.innerHTML = '<tr><td colspan="18" class="muted">No ESPP purchases yet.</td></tr>';
  }
  let totRemaining = new Decimal(String(totShares)).minus(new Decimal(String(totSold)));
  tfoot.innerHTML = `<tr>
    <td colspan="4"><strong>Total</strong></td>
    <td></td><td></td>
    <td>${fmtUSD(totPurUSD.toNumber())}</td><td>${fmtCAD(totPurCAD.toNumber())}</td>
    <td>${fmtUSD(totFmvUSD.toNumber())}</td><td>${fmtCAD(totFmvCAD.toNumber())}</td>
    <td class="gain">${fmtUSD(totBenUSD.toNumber())}</td><td class="gain">${fmtCAD(totBenCAD.toNumber())}</td>
    <td></td><td></td>
    <td>${totSold}</td>
    <td>${totRemaining.gt(0) ? fmtN(totRemaining.toNumber()) : 0}</td>
    <td></td><td></td>
  </tr>`;
}

function editESPP(i) {
  let e = esppPurchases[i];
  editingEsppIdx = i;
  document.getElementById('ef-date').value           = e.date;
  document.getElementById('ef-shares').value         = e.shares;
  document.getElementById('ef-purchase-price').value = e.purchasePriceUSD;
  document.getElementById('ef-fmv').value            = e.fmvUSD;
  document.getElementById('ef-fx').value             = e.fx;
  document.getElementById('ef-fx-cad').value         = e.fxCad || parseFloat((1 / +e.fx).toFixed(6));
  document.getElementById('ef-notes').value          = e.notes || '';
  document.getElementById('ef-fx-display').textContent = '';
  document.getElementById('ef-fx-cad-display').textContent = '';
  document.getElementById('espp-form').classList.remove('hidden');
  updateEsppPreview();
}
function deleteESPP(i) {
  showModal('Delete ESPP Purchase', `Delete ESPP purchase on ${esppPurchases[i].date}?`, () => {
    esppPurchases.splice(i, 1); saveData(); renderAll();
  });
}

// ============================================================
// SALES SECTION
// ============================================================
document.getElementById('btn-add-sale').addEventListener('click', () => {
  editingSaleIdx = null;
  ['sf-date','sf-shares','sf-price','sf-fx','sf-notes'].forEach(id =>
    document.getElementById(id).value = '');
  document.getElementById('sf-commission').value = '0';
  document.getElementById('sf-preview').innerHTML = '';
  document.getElementById('sf-fx-display').textContent = '';
  document.getElementById('sale-breakdown-rows').innerHTML = '';
  document.getElementById('breakdown-total-display').textContent = '';
  addBreakdownRow();
  document.getElementById('sale-form').classList.remove('hidden');
});

// ── Build source type options ──
function buildSourceTypeOptions(selected) {
  let html = '<option value="">— Type —</option>';
  if (grants.length > 0) html += `<option value="rsu" ${selected==='rsu'?'selected':''}>RSU Grant</option>`;
  if (esppPurchases.length > 0) html += `<option value="espp" ${selected==='espp'?'selected':''}>ESPP</option>`;
  return html;
}

// ── Build the second dropdown based on source type ──
function buildSourceOptions(sourceType, selectedId) {
  if (sourceType === 'rsu') {
    let html = '<option value="">— Grant —</option>';
    grants.forEach(g => {
      let sel = selectedId === g.grantId ? 'selected' : '';
      html += `<option value="${g.grantId}" ${sel}>${g.grantId} (${g.grantDate})</option>`;
    });
    return html;
  } else if (sourceType === 'espp') {
    let html = '<option value="">— Purchase —</option>';
    esppPurchases.forEach((e, i) => {
      let soldFromSales = calcEsppSoldFromSales(i);
      let remaining = Math.max(0, +e.shares - soldFromSales);
      let sel = selectedId === `espp-${i}` ? 'selected' : '';
      html += `<option value="espp-${i}" ${sel}>${e.date} — ${e.shares} shares (${fmtN(remaining)} rem.)</option>`;
    });
    return html;
  }
  return '<option value="">—</option>';
}

// ── Build vest period dropdown for RSU grants ──
function buildVestOptions(grantId, selectedVest) {
  let html = '<option value="">— Vest Period —</option>';
  if (!grantId) return html;
  let g = grants.find(x => x.grantId === grantId);
  if (!g) return html;
  g.vests.forEach((v, vi) => {
    if (!v.vested) return;
    let net = +v.netShares || (+v.grossShares - (+v.withheld || 0));
    let sold = calcRsuSoldFromSales(grantId, v.date);
    let remaining = Math.max(0, net - sold);
    let sel = selectedVest === v.date ? 'selected' : '';
    html += `<option value="${v.date}" ${sel}>P${vi+1} — ${v.date} (${fmtN(remaining)} rem.)</option>`;
  });
  return html;
}

// ── Calculate shares sold for an RSU vest period from sales breakdown ──
function calcRsuSoldFromSales(grantId, vestDate) {
  return sales.reduce((sum, s) => {
    if (s.breakdown && s.breakdown.length > 0) {
      return sum + s.breakdown
        .filter(b => b.sourceType === 'rsu' && b.sourceId === grantId && b.vestDate === vestDate)
        .reduce((a, b) => a + (+b.shares || 0), 0);
    }
    // Legacy format
    if (s.grantId === grantId && s.vestDate === vestDate) return sum + (+s.shares || 0);
    return sum;
  }, 0);
}

// ── Calculate shares sold for an ESPP purchase from sales breakdown ──
function calcEsppSoldFromSales(esppIdx) {
  let key = `espp-${esppIdx}`;
  return sales.reduce((sum, s) => {
    if (s.breakdown && s.breakdown.length > 0) {
      return sum + s.breakdown
        .filter(b => b.sourceType === 'espp' && b.sourceId === key)
        .reduce((a, b) => a + (+b.shares || 0), 0);
    }
    return sum;
  }, 0);
}

function addBreakdownRow(data = null) {
  let c = document.getElementById('sale-breakdown-rows');
  let div = document.createElement('div');
  div.className = 'sale-breakdown-row';

  let sourceType = data ? (data.sourceType || (data.grantId ? 'rsu' : '')) : '';
  let sourceId   = data ? (data.sourceId || data.grantId || '') : '';
  let vestDate   = data ? (data.vestDate || '') : '';

  div.innerHTML = `
    <input type="number" class="br-shares" placeholder="Shares" value="${data ? data.shares : ''}" min="0" step="0.001">
    <select class="br-type">${buildSourceTypeOptions(sourceType)}</select>
    <select class="br-source">${buildSourceOptions(sourceType, sourceId)}</select>
    <select class="br-vest">${sourceType==='rsu' ? buildVestOptions(sourceId, vestDate) : '<option value="">— N/A for ESPP —</option>'}</select>
    <button class="btn-remove-vest-row" onclick="removeBreakdownRow(this)">✕</button>`;
  c.appendChild(div);

  let typeEl   = div.querySelector('.br-type');
  let sourceEl = div.querySelector('.br-source');
  let vestEl   = div.querySelector('.br-vest');

  typeEl.addEventListener('change', function() {
    sourceEl.innerHTML = buildSourceOptions(this.value, '');
    if (this.value === 'rsu') {
      vestEl.innerHTML = buildVestOptions('', '');
    } else {
      vestEl.innerHTML = '<option value="">— N/A for ESPP —</option>';
    }
    vestEl.style.display = '';
    updateBreakdownTotal();
  });
  sourceEl.addEventListener('change', function() {
    if (typeEl.value === 'rsu') {
      vestEl.innerHTML = buildVestOptions(this.value, '');
    }
    vestEl.style.display = '';
    updateBreakdownTotal();
  });
  div.querySelector('.br-shares').addEventListener('input', updateBreakdownTotal);
  vestEl.addEventListener('change', updateBreakdownTotal);
}

function removeBreakdownRow(btn) {
  btn.parentElement.remove();
  updateBreakdownTotal();
}

function updateBreakdownTotal() {
  let total = getBreakdownTotal();
  let shares = parseFloat(document.getElementById('sf-shares').value) || 0;
  let disp = document.getElementById('breakdown-total-display');
  if (total === 0) { disp.textContent = ''; return; }
  if (shares > 0) {
    let diff = shares - total;
    if (Math.abs(diff) < 0.001) {
      disp.innerHTML = `<span class="breakdown-total-ok">✓ ${fmtN(total)} shares accounted for</span>`;
    } else {
      disp.innerHTML = `<span class="breakdown-total-err">${fmtN(total)} / ${fmtN(shares)} — ${diff > 0 ? fmtN(diff) + ' remaining' : fmtN(Math.abs(diff)) + ' over'}</span>`;
    }
  } else {
    disp.textContent = `${fmtN(total)} shares entered`;
  }
}

function getBreakdownTotal() {
  let rows = document.querySelectorAll('#sale-breakdown-rows .sale-breakdown-row');
  let t = 0;
  rows.forEach(r => { t += parseFloat(r.querySelector('.br-shares').value) || 0; });
  return t;
}

function readBreakdownRows() {
  let rows = document.querySelectorAll('#sale-breakdown-rows .sale-breakdown-row');
  let result = [];
  rows.forEach(r => {
    let shares     = parseFloat(r.querySelector('.br-shares').value) || 0;
    let sourceType = r.querySelector('.br-type').value;
    let sourceId   = r.querySelector('.br-source').value;
    let vestEl     = r.querySelector('.br-vest');
    let vestDate   = vestEl ? vestEl.value : '';
    if (shares > 0 || sourceType) {
      result.push({ shares, sourceType, sourceId, vestDate });
    }
  });
  return result;
}

document.getElementById('btn-add-breakdown-row').addEventListener('click', () => addBreakdownRow());

document.getElementById('sf-shares').addEventListener('input', updateBreakdownTotal);

document.getElementById('btn-cancel-sale').addEventListener('click', () => {
  document.getElementById('sale-form').classList.add('hidden');
  editingSaleIdx = null;
});

['sf-shares','sf-price','sf-fx','sf-commission'].forEach(id =>
  document.getElementById(id).addEventListener('input', updateSalePreview));

function updateSalePreview() {
  let shares  = parseFloat(document.getElementById('sf-shares').value) || 0;
  let price   = parseFloat(document.getElementById('sf-price').value);
  let fx      = parseFloat(document.getElementById('sf-fx').value);
  let comm    = parseFloat(document.getElementById('sf-commission').value) || 0;
  let prev    = document.getElementById('sf-preview');
  if (!price || !fx) { prev.innerHTML = ''; return; }
  // Use Decimal for preview calculations
  let dShares  = new Decimal(String(shares));
  let dPrice   = new Decimal(String(price));
  let dFx      = new Decimal(String(fx));
  let dComm    = new Decimal(String(comm));
  let dProcUSD = dShares.times(dPrice).minus(dComm);
  let dProcCAD = dProcUSD.times(dFx);
  // Get current ACB at pool level
  let ledger = buildACBLedger();
  let last   = ledger[ledger.length-1];
  let lastDecShares = last && last._decRunShares ? last._decRunShares : new Decimal(String(last ? last.runShares : 0));
  let lastDecACBcad = last && last._decRunACBcad ? last._decRunACBcad : new Decimal(String(last ? last.runACBcad : 0));
  let lastDecACBusd = last && last._decRunACBusd ? last._decRunACBusd : new Decimal(String(last ? last.runACBusd : 0));
  let dAcbSoldCAD = lastDecShares.gt(0) ? lastDecACBcad.div(lastDecShares).times(dShares) : new Decimal(0);
  let dAcbSoldUSD = lastDecShares.gt(0) ? lastDecACBusd.div(lastDecShares).times(dShares) : new Decimal(0);
  let dGlCAD = dProcCAD.minus(dAcbSoldCAD);
  let dGlUSD = dProcUSD.minus(dAcbSoldUSD);
  let glCAD = dGlCAD.toNumber(), glUSD = dGlUSD.toNumber();
  let procUSD = dProcUSD.toNumber(), procCAD = dProcCAD.toNumber();
  let acbSoldCAD = dAcbSoldCAD.toNumber();
  let acbPSCAD = lastDecShares.gt(0) ? lastDecACBcad.div(lastDecShares).toNumber() : null;
  prev.innerHTML = `
    <div class="preview-item"><span class="preview-label">Proceeds (USD)</span><span class="preview-value">${fmtUSD(procUSD)}</span></div>
    <div class="preview-item"><span class="preview-label">Proceeds (CAD)</span><span class="preview-value">${fmtCAD(procCAD)}</span></div>
    <div class="preview-item"><span class="preview-label">ACB Sold (CAD)</span><span class="preview-value">${fmtCAD(acbSoldCAD)}</span></div>
    <div class="preview-item"><span class="preview-label">Est. Gain/Loss (CAD)</span><span class="preview-value ${glCAD>=0?'gain':'loss'}">${fmtSigned(glCAD, fmtCAD)}</span></div>
    <div class="preview-item"><span class="preview-label">Est. Gain/Loss (USD)</span><span class="preview-value ${glUSD>=0?'gain':'loss'}">${fmtSigned(glUSD, fmtUSD)}</span></div>
    <div class="preview-item"><span class="preview-label">Current Pool ACB/Share (CAD)</span><span class="preview-value">${acbPSCAD !== null ? fmtCAD(acbPSCAD) : 'N/A'}</span></div>`;
}

document.getElementById('btn-save-sale').addEventListener('click', () => {
  let date     = document.getElementById('sf-date').value;
  let shares   = parseFloat(document.getElementById('sf-shares').value);
  let price    = parseFloat(document.getElementById('sf-price').value);
  let fx       = parseFloat(document.getElementById('sf-fx').value);
  let comm     = parseFloat(document.getElementById('sf-commission').value) || 0;
  let notes    = document.getElementById('sf-notes').value.trim();
  let breakdown = readBreakdownRows();
  if (!date || isNaN(shares) || isNaN(price) || isNaN(fx)) {
    alert('Please fill in Date, Shares, Price, and FX Rate.'); return;
  }
  // Warn if breakdown total doesn't match (but allow saving anyway)
  let bTotal = breakdown.reduce((s, b) => s + +b.shares, 0);
  if (breakdown.length > 0 && bTotal > 0 && Math.abs(bTotal - shares) >= 0.001) {
    if (!confirm(`Breakdown total (${fmtN(bTotal)}) doesn't match Shares Sold (${fmtN(shares)}). Save anyway?`)) return;
  }
  let rec = { id: uid(), date, shares, priceUSD: price, fx, commissionUSD: comm, notes, breakdown };
  if (editingSaleIdx !== null) { sales[editingSaleIdx] = { ...sales[editingSaleIdx], ...rec }; }
  else { sales.push(rec); }
  saveData(); renderAll();
  document.getElementById('sale-form').classList.add('hidden');
  editingSaleIdx = null;
  showToast('Sale recorded.');
});

function renderSales(ledger) {
  let tbody = document.getElementById('sales-body');
  let tfoot = document.getElementById('sales-foot');
  tbody.innerHTML = '';

  // Map saleIdx → ACB info from ledger
  let saleACBmap = {};
  for (let ev of ledger) {
    if (ev.type === 'sale') saleACBmap[ev.saleIdx] = ev;
  }

  if (!sales.length) {
    tbody.innerHTML = '<tr><td colspan="14" class="muted">No sales recorded yet.</td></tr>';
    tfoot.innerHTML = '';
    return;
  }

  // Preserve which years are currently open across re-renders
  if (!renderSales._openYears) renderSales._openYears = {};

  // Sort sales chronologically, keeping original index
  let sorted = sales
    .map((s, i) => ({ ...s, origIdx: i }))
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  // Group by year
  let byYear = {};
  sorted.forEach(s => {
    let yr = new Date(s.date + 'T00:00:00').getFullYear();
    if (!byYear[yr]) byYear[yr] = [];
    byYear[yr].push(s);
  });

  let totProcUSD = new Decimal(0), totProcCAD = new Decimal(0);
  let totACBusd  = new Decimal(0), totACBcad  = new Decimal(0);
  let totGLusd   = new Decimal(0), totGLcad   = new Decimal(0);
  const COLS = 14;

  Object.keys(byYear).sort().forEach(yr => {
    // Default: most recent year open, others closed
    let years = Object.keys(byYear).sort();
    let mostRecent = years[years.length - 1];
    if (renderSales._openYears[yr] === undefined) {
      renderSales._openYears[yr] = (yr === mostRecent);
    }
    let isOpen = renderSales._openYears[yr];

    // ── Pre-calculate year totals for the header using Decimal ──
    let yrProcUSD = new Decimal(0), yrProcCAD = new Decimal(0);
    let yrACBusd  = new Decimal(0), yrACBcad  = new Decimal(0);
    let yrGLusd   = new Decimal(0), yrGLcad   = new Decimal(0);
    byYear[yr].forEach(s => {
      let ev = saleACBmap[s.origIdx] || {};
      let dShares  = new Decimal(String(+s.shares));
      let dPrice   = new Decimal(String(+s.priceUSD));
      let dComm    = new Decimal(String(+s.commissionUSD || 0));
      let dFx      = new Decimal(String(+s.fx));
      let dProcUSD = dShares.times(dPrice).minus(dComm);
      let dProcCAD = dProcUSD.times(dFx);
      yrProcUSD = yrProcUSD.plus(dProcUSD);
      yrProcCAD = yrProcCAD.plus(dProcCAD);
      yrACBusd  = yrACBusd.plus(new Decimal(String(ev.costUSD || 0)));
      yrACBcad  = yrACBcad.plus(new Decimal(String(ev.costCAD || 0)));
      if (ev.gainLossUSD != null) {
        yrGLusd = yrGLusd.plus(new Decimal(String(ev.gainLossUSD)));
        yrGLcad = yrGLcad.plus(new Decimal(String(ev.gainLossCAD)));
      }
      totProcUSD = totProcUSD.plus(dProcUSD);
      totProcCAD = totProcCAD.plus(dProcCAD);
      totACBusd  = totACBusd.plus(new Decimal(String(ev.costUSD || 0)));
      totACBcad  = totACBcad.plus(new Decimal(String(ev.costCAD || 0)));
      if (ev.gainLossUSD != null) {
        totGLusd = totGLusd.plus(new Decimal(String(ev.gainLossUSD)));
        totGLcad = totGLcad.plus(new Decimal(String(ev.gainLossCAD)));
      }
    });

    let yrGLcadn = yrGLcad.toNumber();
    let glClass = yrGLcadn >= 0 ? 'gain' : 'loss';
    let glSign  = yrGLcadn < 0 ? '−' : '';
    let summaryHtml = `<span class="yr-hdr-summary">
      Proceeds: ${fmtCAD(yrProcCAD.toNumber())} &nbsp;|&nbsp;
      Gain/Loss: <span class="${glClass}">${glSign}${fmtCAD(Math.abs(yrGLcadn))}</span>
    </span>`;

    // ── Year header row (clickable) ──
    let yrHdr = document.createElement('tr');
    yrHdr.className = 'sales-year-header';
    yrHdr.dataset.year = yr;
    yrHdr.style.cursor = 'pointer';
    yrHdr.innerHTML = `<td colspan="${COLS}">
      <span class="yr-chevron">${isOpen ? '▼' : '▶'}</span>
      <strong>${yr}</strong>
      <span class="yr-count">${byYear[yr].length} sale${byYear[yr].length !== 1 ? 's' : ''}</span>
      ${summaryHtml}
    </td>`;
    yrHdr.addEventListener('click', () => toggleSalesYear(yr));
    tbody.appendChild(yrHdr);

    // ── Data rows ──
    byYear[yr].forEach(s => {
      let i   = s.origIdx;
      let ev  = saleACBmap[i] || {};
      let dShares  = new Decimal(String(+s.shares));
      let dPrice   = new Decimal(String(+s.priceUSD));
      let dComm    = new Decimal(String(+s.commissionUSD || 0));
      let dFx      = new Decimal(String(+s.fx));
      let dProcUSD = dShares.times(dPrice).minus(dComm);
      let dProcCAD = dProcUSD.times(dFx);
      let procUSD  = dProcUSD.toNumber();
      let procCAD  = dProcCAD.toNumber();
      let acbUSD  = ev.costUSD || 0;
      let acbCAD  = ev.costCAD || 0;
      let glUSD   = ev.gainLossUSD;
      let glCAD   = ev.gainLossCAD;

      // Build breakdown cell
      let breakdownHtml = '—';
      if (s.breakdown && s.breakdown.length > 0) {
        let lines = s.breakdown
          .filter(b => b.shares > 0 || b.sourceType)
          .map(b => {
            let label = '';
            if (b.sourceType === 'espp') {
              let idx = b.sourceId ? parseInt(b.sourceId.replace('espp-','')) : -1;
              let e = esppPurchases[idx];
              label = e ? `ESPP ${e.date}` : 'ESPP';
            } else if (b.sourceType === 'rsu') {
              label = b.sourceId || '';
              if (b.vestDate && b.sourceId) {
                let g = grants.find(x => x.grantId === b.sourceId);
                let vi = g ? g.vests.findIndex(v => v.date === b.vestDate) : -1;
                label += vi >= 0 ? ` P${vi+1}` : ` ${b.vestDate}`;
              }
            } else if (b.grantId) {
              let g = grants.find(x => x.grantId === b.grantId);
              let vi = g && b.vestDate ? g.vests.findIndex(v => v.date === b.vestDate) : -1;
              label = b.grantId + (vi >= 0 ? ` P${vi+1}` : b.vestDate ? ` ${b.vestDate}` : '');
            }
            return `<span style="white-space:nowrap">${fmtN(b.shares)}${label ? ' — ' + label : ''}</span>`;
          });
        breakdownHtml = `<div class="sale-breakdown-summary">${lines.join('<br>')}</div>`;
      } else if (s.grantId) {
        let g = grants.find(x => x.grantId === s.grantId);
        let vi = g && s.vestDate ? g.vests.findIndex(v => v.date === s.vestDate) : -1;
        breakdownHtml = `${s.grantId}${vi >= 0 ? ` P${vi+1}` : s.vestDate ? ' ' + s.vestDate : ''}`;
      }

      let tr = document.createElement('tr');
      tr.dataset.year = yr;
      tr.className = 'sales-yr-row' + (isOpen ? '' : ' hidden');
      tr.innerHTML = `
        <td>${s.date}</td>
        <td>${s.shares}</td>
        <td>${fmtUSD(s.priceUSD)}</td>
        <td>${s.fx}</td>
        <td>${fmtUSD(procUSD)}</td><td>${fmtCAD(procCAD)}</td>
        <td>${fmtUSD(acbUSD)}</td><td>${fmtCAD(acbCAD)}</td>
        <td>${fmtUSD(s.commissionUSD||0)}</td>
        <td>${gainCell(glUSD, fmtUSD)}</td>
        <td>${gainCell(glCAD, fmtCAD)}</td>
        <td>${breakdownHtml}</td>
        <td>${s.notes||'—'}</td>
        <td>
          <button class="btn-sm btn-edit-sm" onclick="editSale(${i})">Edit</button>
          <button class="btn-sm btn-del-sm"  onclick="deleteSale(${i})">Del</button>
        </td>`;
      tbody.appendChild(tr);
    });

    // ── Year subtotal row (hidden when open, shown when collapsed) ──
    let yrSub = document.createElement('tr');
    yrSub.className = 'sales-year-subtotal' + (isOpen ? '' : ' hidden');
    yrSub.dataset.year = yr;
    yrSub.dataset.role = 'subtotal';
    yrSub.innerHTML = `
      <td colspan="4"><strong>${yr} Subtotal</strong></td>
      <td>${fmtUSD(yrProcUSD)}</td><td>${fmtCAD(yrProcCAD)}</td>
      <td>${fmtUSD(yrACBusd)}</td><td>${fmtCAD(yrACBcad)}</td>
      <td></td>
      <td>${gainCell(yrGLusd, fmtUSD)}</td>
      <td>${gainCell(yrGLcad, fmtCAD)}</td>
      <td></td><td></td><td></td>`;
    tbody.appendChild(yrSub);
  });

  // ── Grand total ──
  tfoot.innerHTML = `<tr>
    <td colspan="4"><strong>Grand Total</strong></td>
    <td>${fmtUSD(totProcUSD.toNumber())}</td><td>${fmtCAD(totProcCAD.toNumber())}</td>
    <td>${fmtUSD(totACBusd.toNumber())}</td><td>${fmtCAD(totACBcad.toNumber())}</td>
    <td></td>
    <td>${gainCell(totGLusd.toNumber(), fmtUSD)}</td>
    <td>${gainCell(totGLcad.toNumber(), fmtCAD)}</td>
    <td></td><td></td><td></td>
  </tr>`;
}

function toggleSalesYear(yr) {
  renderSales._openYears[yr] = !renderSales._openYears[yr];
  let isOpen = renderSales._openYears[yr];

  // Toggle data rows and subtotal
  document.querySelectorAll(`tr.sales-yr-row[data-year="${yr}"]`).forEach(r => {
    r.classList.toggle('hidden', !isOpen);
  });
  document.querySelectorAll(`tr.sales-year-subtotal[data-year="${yr}"]`).forEach(r => {
    r.classList.toggle('hidden', !isOpen);
  });

  // Update chevron and header
  let hdr = document.querySelector(`tr.sales-year-header[data-year="${yr}"] .yr-chevron`);
  if (hdr) hdr.textContent = isOpen ? '▼' : '▶';
}

function editSale(i) {
  let s = sales[i];
  editingSaleIdx = i;
  document.getElementById('sf-date').value       = s.date;
  document.getElementById('sf-shares').value     = s.shares;
  document.getElementById('sf-price').value      = s.priceUSD;
  document.getElementById('sf-fx').value         = s.fx;
  document.getElementById('sf-commission').value = s.commissionUSD || 0;
  document.getElementById('sf-notes').value      = s.notes || '';
  // Repopulate breakdown rows
  document.getElementById('sale-breakdown-rows').innerHTML = '';
  if (s.breakdown && s.breakdown.length > 0) {
    s.breakdown.forEach(b => addBreakdownRow(b));
  } else if (s.grantId) {
    // Legacy: migrate single grant/vest to new format
    addBreakdownRow({ shares: s.shares, sourceType: 'rsu', sourceId: s.grantId, vestDate: s.vestDate || '' });
  } else {
    addBreakdownRow();
  }
  updateBreakdownTotal();
  document.getElementById('sf-fx-display').textContent = '';
  document.getElementById('sale-form').classList.remove('hidden');
  updateSalePreview();
}
function deleteSale(i) {
  showModal('Delete Sale', `Delete sale on ${sales[i].date}?`, () => {
    sales.splice(i, 1); saveData(); renderAll();
  });
}

function toggleT4Section() {
  var sec = document.getElementById('gl-t4-section');
  var btn = document.getElementById('btn-toggle-t4');
  var hidden = sec.classList.toggle('hidden');
  btn.textContent = hidden ? 'Unhide' : 'Hide';
}

var glCurrentView = 'cad';
function setGLView(view) {
  glCurrentView = view;
  var cadWrap = document.getElementById('gl-table-cad-wrap');
  var usdWrap = document.getElementById('gl-table-usd-wrap');
  // CAD: shown for 'cad' only
  cadWrap.classList.toggle('hidden', view !== 'cad');
  // USD/Both: shown for 'usd' and 'both' (same table, all columns)
  usdWrap.classList.toggle('hidden', view === 'cad');
  document.getElementById('gl-btn-cad').classList.toggle('active', view === 'cad');
  document.getElementById('gl-btn-usd').classList.toggle('active', view === 'usd');
  document.getElementById('gl-btn-both').classList.toggle('active', view === 'both');
}

// ============================================================
// GAIN / LOSS REPORT  (rewritten from scratch)
// ============================================================
function renderGainLoss(ledger) {

  // ── 1. Filter to sales in the selected tax year ──
  let yrSales = [];
  for (let ev of ledger) {
    if (ev.type !== 'sale') continue;
    if (new Date(ev.date + 'T00:00:00').getFullYear() !== currentYear) continue;
    yrSales.push(ev);
  }

  // ── 2. Compute totals using Decimal ──
  let totProcCAD = new Decimal(0), totACBcad = new Decimal(0), totGLcad = new Decimal(0);
  let totProcUSD = new Decimal(0), totACBusd = new Decimal(0), totGLusd = new Decimal(0);
  yrSales.forEach(ev => {
    totProcCAD = totProcCAD.plus(new Decimal(String(ev.proceedsCAD || 0)));
    totACBcad  = totACBcad.plus(new Decimal(String(ev.costCAD     || 0)));
    totGLcad   = totGLcad.plus(new Decimal(String(ev.gainLossCAD  || 0)));
    totProcUSD = totProcUSD.plus(new Decimal(String(ev.proceedsUSD || 0)));
    totACBusd  = totACBusd.plus(new Decimal(String(ev.costUSD     || 0)));
    totGLusd   = totGLusd.plus(new Decimal(String(ev.gainLossUSD  || 0)));
  });

  // Convert to numbers for display
  let totProcCADn = totProcCAD.toNumber(), totACBcadn = totACBcad.toNumber();
  let totGLcadn   = totGLcad.toNumber(),   totProcUSDn = totProcUSD.toNumber();
  let totACBusdn  = totACBusd.toNumber(),  totGLusdn   = totGLusd.toNumber();

  // 3. Summary cards
  document.getElementById('gl-proceeds-cad').textContent = fmtCAD(totProcCADn);
  document.getElementById('gl-acb-cad').textContent      = fmtCAD(totACBcadn);
  var netEl = document.getElementById('gl-net-cad');
  netEl.textContent = fmtSigned(totGLcadn, fmtCAD);
  netEl.style.color = (totGLcadn >= 0) ? '#1a6e3c' : '#c0392b';
  document.getElementById('gl-taxable-cad').textContent = fmtCAD(new Decimal(String(Math.max(0, totGLcadn))).times('0.5').toNumber());

  // 4. Dispositions — CAD table
  var glBodyCAD = document.getElementById('gl-body-cad');
  var glFootCAD = document.getElementById('gl-foot-cad');
  var glBodyUSD = document.getElementById('gl-body-usd');
  var glFootUSD = document.getElementById('gl-foot-usd');
  glBodyCAD.innerHTML = glBodyUSD.innerHTML = '';

  if (yrSales.length === 0) {
    glBodyCAD.innerHTML = '<tr><td colspan="7" class="muted">No dispositions in ' + currentYear + '.</td></tr>';
    glBodyUSD.innerHTML = '<tr><td colspan="11" class="muted">No dispositions in ' + currentYear + '.</td></tr>';
    if (glFootCAD) glFootCAD.innerHTML = '';
    if (glFootUSD) glFootUSD.innerHTML = '';
  } else {
    var totCommCAD = new Decimal(0), totCommUSD = new Decimal(0);
    for (var di = 0; di < yrSales.length; di++) {
      var dEv  = yrSales[di];
      var dS   = sales[dEv.saleIdx];
      var dFX  = parseFloat(dS.fx) || 1;
      var dCommUSD = new Decimal(String(parseFloat(dS.commissionUSD) || 0));
      var dCommCAD = dCommUSD.times(new Decimal(String(dFX)));
      totCommUSD = totCommUSD.plus(dCommUSD);
      totCommCAD = totCommCAD.plus(dCommCAD);

      // CAD row: Date, Shares, FX, Proceeds(CAD), ACB(CAD), Commission(CAD), G/L(CAD)
      var trCAD = document.createElement('tr');
      trCAD.innerHTML =
        '<td>' + dEv.date + '</td>' +
        '<td>' + dS.shares + '</td>' +
        '<td>' + dFX.toFixed(4) + '</td>' +
        '<td>' + fmtCAD(dEv.proceedsCAD) + '</td>' +
        '<td>' + fmtCAD(dEv.costCAD) + '</td>' +
        '<td>' + fmtCAD(dCommCAD.toNumber()) + '</td>' +
        '<td>' + gainCell(dEv.gainLossCAD, fmtCAD) + '</td>';
      glBodyCAD.appendChild(trCAD);

      // USD row: Date, Shares, Proceeds(USD), ACB(USD), Comm(USD), G/L(USD), FX, Proceeds(CAD), ACB(CAD), Comm(CAD), G/L(CAD)
      var trUSD = document.createElement('tr');
      trUSD.innerHTML =
        '<td>' + dEv.date + '</td>' +
        '<td>' + dS.shares + '</td>' +
        '<td>' + fmtUSD(dEv.proceedsUSD) + '</td>' +
        '<td>' + fmtUSD(dEv.costUSD) + '</td>' +
        '<td>' + fmtUSD(dCommUSD.toNumber()) + '</td>' +
        '<td>' + gainCell(dEv.gainLossUSD, fmtUSD) + '</td>' +
        '<td>' + dFX.toFixed(4) + '</td>' +
        '<td>' + fmtCAD(dEv.proceedsCAD) + '</td>' +
        '<td>' + fmtCAD(dEv.costCAD) + '</td>' +
        '<td>' + fmtCAD(dCommCAD.toNumber()) + '</td>' +
        '<td>' + gainCell(dEv.gainLossCAD, fmtCAD) + '</td>';
      glBodyUSD.appendChild(trUSD);
    }

    glFootCAD.innerHTML =
      '<tr><td colspan="2"><strong>Total</strong></td>' +
      '<td></td>' +
      '<td>' + fmtCAD(totProcCADn) + '</td>' +
      '<td>' + fmtCAD(totACBcadn) + '</td>' +
      '<td>' + fmtCAD(totCommCAD.toNumber()) + '</td>' +
      '<td>' + gainCell(totGLcadn, fmtCAD) + '</td></tr>';

    glFootUSD.innerHTML =
      '<tr><td colspan="2"><strong>Total</strong></td>' +
      '<td>' + fmtUSD(totProcUSDn) + '</td>' +
      '<td>' + fmtUSD(totACBusdn) + '</td>' +
      '<td>' + fmtUSD(totCommUSD.toNumber()) + '</td>' +
      '<td>' + gainCell(totGLusdn, fmtUSD) + '</td>' +
      '<td></td>' +
      '<td>' + fmtCAD(totProcCADn) + '</td>' +
      '<td>' + fmtCAD(totACBcadn) + '</td>' +
      '<td>' + fmtCAD(totCommCAD.toNumber()) + '</td>' +
      '<td>' + gainCell(totGLcadn, fmtCAD) + '</td></tr>';
  }

  // 5. T4 employment income table — RSU vests + ESPP purchases
  var vBody = document.getElementById('gl-vest-body');
  var vFoot = document.getElementById('gl-vest-foot');
  vBody.innerHTML = '';
  var dTotEmpUSD = new Decimal(0), dTotEmpCAD = new Decimal(0);

  // Collect all rows: RSU vests + ESPP purchases, sorted by date
  var t4Rows = [];

  // RSU vests
  for (var tgi = 0; tgi < grants.length; tgi++) {
    var tg = grants[tgi];
    for (var tvi = 0; tvi < tg.vests.length; tvi++) {
      var tv = tg.vests[tvi];
      if (!tv.vested || !tv.fmvUSD || !tv.fx) continue;
      if (new Date(tv.date + 'T00:00:00').getFullYear() !== currentYear) continue;
      var dNet    = new Decimal(String((+tv.netShares) || ((+tv.grossShares) - (+tv.withheld || 0))));
      var tNet    = dNet.toNumber();
      var dFmvTotal = tv.fmvTotalUSD ? new Decimal(String(+tv.fmvTotalUSD)) : dNet.times(new Decimal(String(+tv.fmvUSD)));
      var dFmvPS  = tNet > 0 ? dFmvTotal.div(dNet) : new Decimal(String(+tv.fmvUSD));
      var tFMVps  = dFmvPS.toNumber();
      var dEmpUSD = dNet.times(dFmvPS);
      var dEmpCAD = dEmpUSD.times(new Decimal(String(+tv.fx)));
      var tEmpUSD = dEmpUSD.toNumber();
      var tEmpCAD = dEmpCAD.toNumber();
      t4Rows.push({ date: tv.date, type: 'RSU Vest', source: tg.grantId, shares: tNet, fmvPS: tFMVps, fx: +tv.fx, empUSD: tEmpUSD, empCAD: tEmpCAD, box: 'Box 14' });
    }
  }

  // ESPP purchases — taxable benefit = (FMV - purchase price) × shares
  for (var epi = 0; epi < esppPurchases.length; epi++) {
    var ep = esppPurchases[epi];
    if (!ep.fmvUSD || !ep.fx) continue;
    if (new Date(ep.date + 'T00:00:00').getFullYear() !== currentYear) continue;
    var epShares  = +ep.shares;
    var dEpBenUSD = new Decimal(String(ep.fmvUSD)).minus(new Decimal(String(ep.purchasePriceUSD))).times(new Decimal(String(epShares)));
    var dEpBenCAD = dEpBenUSD.times(new Decimal(String(+ep.fx)));
    var epBenUSD  = dEpBenUSD.toNumber();
    var epBenCAD  = dEpBenCAD.toNumber();
    t4Rows.push({ date: ep.date, type: 'ESPP', source: ep.date, shares: epShares, fmvPS: +ep.fmvUSD, fx: +ep.fx, empUSD: epBenUSD, empCAD: epBenCAD, box: 'Box 38' });
  }

  t4Rows.sort(function(a, b) { return a.date < b.date ? -1 : 1; });

  if (t4Rows.length === 0) {
    vBody.innerHTML = '<tr><td colspan="9" class="muted">No RSU vests or ESPP purchases recorded in ' + currentYear + '.</td></tr>';
  } else {
    for (var ti = 0; ti < t4Rows.length; ti++) {
      var row = t4Rows[ti];
      dTotEmpUSD = dTotEmpUSD.plus(new Decimal(String(row.empUSD)));
      dTotEmpCAD = dTotEmpCAD.plus(new Decimal(String(row.empCAD)));
      var vTr = document.createElement('tr');
      vTr.innerHTML =
        '<td><span class="tag ' + (row.type === 'RSU Vest' ? 'tag-rsu' : 'tag-espp') + '">' + row.type + '</span></td>' +
        '<td>' + row.source + '</td>' +
        '<td>' + row.date + '</td>' +
        '<td>' + fmtN(row.shares) + '</td>' +
        '<td>' + fmtUSD(row.fmvPS) + '</td>' +
        '<td>' + row.fx.toFixed(4) + '</td>' +
        '<td>' + fmtUSD(row.empUSD) + '</td>' +
        '<td>' + fmtCAD(row.empCAD) + '</td>' +
        '<td>' + row.box + '</td>';
      vBody.appendChild(vTr);
    }
  }
  vFoot.innerHTML =
    '<tr><td colspan="6"><strong>Total Employment Income</strong></td>' +
    '<td>' + fmtUSD(dTotEmpUSD.toNumber()) + '</td>' +
    '<td>' + fmtCAD(dTotEmpCAD.toNumber()) + '</td>' +
    '<td></td></tr>';
}

// ============================================================
// ACB LEDGER  (year drawers)
// ============================================================
if (!window.acbOpenYears) window.acbOpenYears = {};

function toggleACBYear(yr) {
  window.acbOpenYears[yr] = !window.acbOpenYears[yr];
  var rows = document.querySelectorAll('tr.acb-yr-row[data-yr="' + yr + '"]');
  var chev = document.getElementById('acb-chev-' + yr);
  for (var i = 0; i < rows.length; i++) {
    rows[i].classList.toggle('hidden', !window.acbOpenYears[yr]);
  }
  if (chev) chev.textContent = window.acbOpenYears[yr] ? '▼' : '▶';
}

function renderACBLedger(ledger) {
  var acbBody = document.getElementById('acb-body');
  if (!acbBody) { console.error('renderACBLedger: acb-body element not found'); return; }
  acbBody.innerHTML = '';

  if (!ledger || ledger.length === 0) {
    acbBody.innerHTML = '<tr><td colspan="11" class="muted">No events yet. Add grants and record vests to see your ACB ledger.</td></tr>';
    return;
  }

  // Group events by year
  var byYear = {};
  var yearOrder = [];
  for (var i = 0; i < ledger.length; i++) {
    var ev = ledger[i];
    var yr = new Date(ev.date + 'T00:00:00').getFullYear();
    if (!byYear[yr]) { byYear[yr] = []; yearOrder.push(yr); }
    byYear[yr].push(ev);
  }

  // Default: most recent year open, rest closed
  var latestYr = yearOrder[yearOrder.length - 1];
  for (var yi = 0; yi < yearOrder.length; yi++) {
    var y = yearOrder[yi];
    if (window.acbOpenYears[y] === undefined) {
      window.acbOpenYears[y] = (y === latestYr);
    }
  }

  for (var yi = 0; yi < yearOrder.length; yi++) {
    var yr = yearOrder[yi];
    var evs = byYear[yr];
    var isOpen = window.acbOpenYears[yr];

    // Carry-forward row (opening state at start of year = state at end of previous year)
    // Find the last event BEFORE this year
    var prevShares = 0, prevACBusd = 0, prevACBcad = 0;
    for (var pi = 0; pi < ledger.length; pi++) {
      var pev = ledger[pi];
      if (new Date(pev.date + 'T00:00:00').getFullYear() < yr) {
        prevShares = pev.runShares;
        prevACBusd = pev.runACBusd;
        prevACBcad = pev.runACBcad;
      }
    }

    // Year header row
    var hdr = document.createElement('tr');
    hdr.className = 'acb-year-header';
    hdr.style.cursor = 'pointer';
    hdr.onclick = (function(y) { return function() { toggleACBYear(y); }; })(yr);
    hdr.innerHTML =
      '<td colspan="11">' +
      '<span id="acb-chev-' + yr + '" style="margin-right:8px;font-size:11px;display:inline-block">' + (isOpen ? '▼' : '▶') + '</span>' +
      '<strong>' + yr + '</strong>' +
      '<span style="background:rgba(255,255,255,0.2);border-radius:10px;font-size:11px;font-weight:normal;padding:1px 8px;margin-left:8px">' + evs.length + ' event' + (evs.length !== 1 ? 's' : '') + '</span>' +
      '</td>';
    acbBody.appendChild(hdr);

    // Carry-forward row (shown when year is expanded)
    if (prevShares > 0) {
      var cfRow = document.createElement('tr');
      cfRow.className = 'acb-carryforward' + (isOpen ? '' : ' hidden');
      cfRow.dataset.yr = yr;
      cfRow.classList.add('acb-yr-row');
      var cfPS_usd = prevShares > 0 ? fmtUSD(prevACBusd / prevShares) : '—';
      var cfPS_cad = prevShares > 0 ? fmtCAD(prevACBcad / prevShares) : '—';
      cfRow.innerHTML =
        '<td>—</td>' +
        '<td><em>Carried forward</em></td>' +
        '<td>—</td><td>—</td><td>—</td><td>—</td>' +
        '<td>' + fmtN(prevShares) + '</td>' +
        '<td>' + fmtUSD(prevACBusd) + '</td>' +
        '<td>' + fmtCAD(prevACBcad) + '</td>' +
        '<td>' + cfPS_usd + '</td>' +
        '<td>' + cfPS_cad + '</td>';
      acbBody.appendChild(cfRow);
    }

    // Event rows
    for (var ei = 0; ei < evs.length; ei++) {
      var aEv    = evs[ei];
      var aIsAcq = (aEv.type !== 'sale');
      var aCls   = aIsAcq ? 'gain' : 'loss';

      var aLabel;
      if      (aEv.type === 'vest') aLabel = 'RSU Vest';
      else if (aEv.type === 'espp') aLabel = 'ESPP Buy';
      else if (aEv.type === 'drip') aLabel = 'DRIP Div';
      else                          aLabel = 'Sale';

      var aTagCls;
      if      (aEv.type === 'sale') aTagCls = 'tag-future';
      else if (aEv.type === 'espp') aTagCls = 'tag-espp';
      else if (aEv.type === 'drip') aTagCls = 'tag-drip';
      else                          aTagCls = 'tag-rsu';

      var aDelta = (aEv.sharesDelta > 0 ? '+' : '') + fmtN(aEv.sharesDelta);
      var aCostU = (aIsAcq ? '+' : '-') + fmtUSD(aEv.costUSD);
      var aCostC = (aIsAcq ? '+' : '-') + fmtCAD(aEv.costCAD);
      var aPSusd = aEv.runShares > 0 ? fmtUSD(aEv._decRunACBusd ? aEv._decRunACBusd.div(aEv._decRunShares).toNumber() : aEv.runACBusd / aEv.runShares) : '\u2014';
      var aPScad = aEv.runShares > 0 ? fmtCAD(aEv._decRunACBcad ? aEv._decRunACBcad.div(aEv._decRunShares).toNumber() : aEv.runACBcad / aEv.runShares) : '\u2014';

      var aTr = document.createElement('tr');
      aTr.className = 'acb-yr-row' + (isOpen ? '' : ' hidden');
      aTr.dataset.yr = yr;
      aTr.innerHTML =
        '<td>' + aEv.date + '</td>' +
        '<td><span class="tag ' + aTagCls + '">' + aLabel + '</span></td>' +
        '<td>' + aEv.source + '</td>' +
        '<td class="' + aCls + '">' + aDelta + '</td>' +
        '<td class="' + aCls + '">' + aCostU + '</td>' +
        '<td class="' + aCls + '">' + aCostC + '</td>' +
        '<td>' + fmtN(aEv.runShares)  + '</td>' +
        '<td>' + fmtUSD(aEv.runACBusd) + '</td>' +
        '<td>' + fmtCAD(aEv.runACBcad) + '</td>' +
        '<td>' + aPSusd + '</td>' +
        '<td>' + aPScad + '</td>';
      acbBody.appendChild(aTr);
    }
  }
}

// ============================================================
// EXPORT / IMPORT JSON
// ============================================================
document.getElementById('btn-export-json').addEventListener('click', () => {
  let data = { grants, esppPurchases, sales, dividends, skippedDivQuarters, currentYear, exportedAt: new Date().toISOString() };
  let blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  let a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `equity-tracker-${currentYear}.json`;
  a.click();
  URL.revokeObjectURL(a.href);
  showToast('JSON exported.');
});
document.getElementById('btn-import-json').addEventListener('click', () => {
  document.getElementById('import-json-input').click();
});
document.getElementById('import-json-input').addEventListener('change', function(e) {
  let file = e.target.files[0]; if (!file) return;
  let reader = new FileReader();
  reader.onload = ev => {
    let data;
    try { data = JSON.parse(ev.target.result); } catch { alert('Invalid JSON file.'); return; }
    showModal('Import Data?', 'This will REPLACE all current data. Proceed?', () => {
      grants        = data.grants        || [];
      esppPurchases = data.esppPurchases || [];
      sales         = data.sales         || [];
      dividends     = data.dividends     || [];
      skippedDivQuarters = data.skippedDivQuarters || [];
      currentYear   = data.currentYear   || new Date().getFullYear();
      yearInput.value = currentYear;
      saveData(); renderAll();
      showToast('Data imported.');
    });
  };
  reader.readAsText(file);
  this.value = '';
});

// ============================================================
// EXPORT CSV
// ============================================================
document.getElementById('btn-export-csv').addEventListener('click', () => {
  let ledger = buildACBLedger();
  let csv = `"Equity Tracker — ${currentYear}"\n"Exported: ${new Date().toLocaleDateString('en-CA')}"\n\n`;

  // ── RSU Grant Schedule ──
  csv += 'RSU GRANT SCHEDULE\n';
  csv += 'Grant ID,Grant Date,Total Shares,Period,Vest Date,Grant Qty,Status,Vested,Shares Sold for Taxes,Net Received,FMV Total (USD),FMV/Share (USD),FX Rate,Cost (USD),Cost/Share (USD),Cost (CAD),Cost/Share (CAD),Sold (Tracking),Remaining (Tracking)\n';
  for (let g of grants) {
    let soldByVest = {};
    for (let s of sales) {
      if (s.breakdown && s.breakdown.length > 0) {
        for (let b of s.breakdown) {
          if ((b.sourceType === 'rsu' || !b.sourceType) && (b.sourceId === g.grantId || b.grantId === g.grantId) && b.vestDate) {
            soldByVest[b.vestDate] = (soldByVest[b.vestDate] || 0) + (+b.shares || 0);
          }
        }
      } else if (s.grantId === g.grantId && s.vestDate) {
        soldByVest[s.vestDate] = (soldByVest[s.vestDate] || 0) + +s.shares;
      }
    }
    g.vests.forEach((v, vi) => {
      let isVested = v.vested && v.fmvUSD;
      let net = isVested ? (+v.netShares || +v.grossShares - (+v.withheld||0)) : '';
      let dNet     = isVested ? new Decimal(String(+net)) : null;
      let dFmvPS   = isVested ? new Decimal(String(+v.fmvUSD)) : null;
      let dFx      = isVested ? new Decimal(String(+v.fx)) : null;
      let fmvTotal = isVested ? (v.fmvTotalUSD || dNet.times(dFmvPS).toNumber()) : '';
      let costUSD  = isVested ? dNet.times(dFmvPS).toNumber() : '';
      let costCAD  = isVested ? new Decimal(String(costUSD)).times(dFx).toNumber() : '';
      let soldQty  = soldByVest[v.date] || 0;
      let remaining = isVested ? Math.max(0, net - soldQty) : '';
      let costPSusd = isVested && dNet && dNet.gt(0) ? new Decimal(String(costUSD)).div(dNet).toFixed(4) : '';
      let costPScad = isVested && dNet && dNet.gt(0) ? new Decimal(String(costCAD)).div(dNet).toFixed(4) : '';
      csv += `${g.grantId},${g.grantDate},${g.totalShares},P${vi+1},${v.date},${v.grossShares},${isVested?'Vested':'Future'},${isVested?v.grossShares:''},${isVested?(v.withheld||0):''},${net},${fmvTotal?parseFloat(fmvTotal).toFixed(2):''},${isVested?v.fmvUSD:''},${v.fx||''},${costUSD!==''?parseFloat(costUSD).toFixed(2):''},${costPSusd},${costCAD!==''?parseFloat(costCAD).toFixed(2):''},${costPScad},${isVested?soldQty:''},${remaining!==''?remaining:''}\n`;
    });
    csv += '\n';
  }

  // ── ESPP Purchases ──
  csv += 'ESPP PURCHASES\n';
  csv += 'Date,Shares,Purchase Price/Share (USD),FMV/Share (USD),FX (USD→CAD),Purchase Cost (USD),Purchase Cost (CAD),FMV on Purchase (USD),FMV on Purchase (CAD),Taxable Benefit (USD),Taxable Benefit (CAD),ACB/Share (USD),ACB/Share (CAD),Shares Sold,Shares Remaining\n';
  for (let [i, e] of esppPurchases.entries()) {
    let dShares  = new Decimal(String(+e.shares));
    let dPurPS   = new Decimal(String(+e.purchasePriceUSD));
    let dFmvPS   = new Decimal(String(+e.fmvUSD));
    let dFx      = new Decimal(String(+e.fx));
    let dPurUSD  = dShares.times(dPurPS);
    let dFmvUSD  = dShares.times(dFmvPS);
    let dBenUSD  = dFmvUSD.minus(dPurUSD);
    let soldQty  = calcEsppSoldFromSales(i);
    let remaining = Math.max(0, +e.shares - soldQty);
    csv += `${e.date},${e.shares},${e.purchasePriceUSD},${e.fmvUSD},${e.fx},${dPurUSD.toFixed(2)},${dPurUSD.times(dFx).toFixed(2)},${dFmvUSD.toFixed(2)},${dFmvUSD.times(dFx).toFixed(2)},${dBenUSD.toFixed(2)},${dBenUSD.times(dFx).toFixed(2)},${e.fmvUSD},${dFmvPS.times(dFx).toFixed(4)},${soldQty},${remaining}\n`;
  }
  csv += '\n';

  // ── Sales ──
  csv += 'SALES\n';
  csv += 'Date,Shares,Price/Share (USD),FX Rate,Proceeds (USD),Proceeds (CAD),ACB Sold (USD),ACB Sold (CAD),Commission (USD),Commission (CAD),Gain/Loss (USD),Gain/Loss (CAD),Source Breakdown,Notes\n';
  let saleACBmap = {};
  for (let ev of ledger) { if (ev.type === 'sale') saleACBmap[ev.saleIdx] = ev; }
  for (let [i, s] of sales.entries()) {
    let ev = saleACBmap[i] || {};
    let dShares  = new Decimal(String(+s.shares));
    let dPrice   = new Decimal(String(+s.priceUSD));
    let dComm    = new Decimal(String(+s.commissionUSD || 0));
    let dFx      = new Decimal(String(+s.fx));
    let dProcUSD = dShares.times(dPrice).minus(dComm);
    let dProcCAD = dProcUSD.times(dFx);
    let dCommCAD = dComm.times(dFx);
    let procUSD  = dProcUSD.toNumber();
    let procCAD  = dProcCAD.toNumber();
    let commCAD  = dCommCAD.toNumber();
    let bdText = '';
    if (s.breakdown && s.breakdown.length > 0) {
      bdText = s.breakdown.filter(b => b.shares > 0).map(b => {
        if (b.sourceType === 'espp') { let idx = b.sourceId ? parseInt(b.sourceId.replace('espp-','')) : -1; let ep = esppPurchases[idx]; return `${b.shares} ESPP ${ep?ep.date:''}`; }
        if (b.sourceType === 'rsu') { let g2 = grants.find(x => x.grantId === b.sourceId); let vi = g2&&b.vestDate ? g2.vests.findIndex(v => v.date === b.vestDate) : -1; return `${b.shares} ${b.sourceId||''}${vi>=0?' P'+(vi+1):''}`.trim(); }
        return `${b.shares} ${b.grantId||''}`.trim();
      }).join(' | ');
    }
    csv += `${s.date},${s.shares},${s.priceUSD},${s.fx},${procUSD.toFixed(2)},${procCAD.toFixed(2)},${(ev.costUSD||0).toFixed(2)},${(ev.costCAD||0).toFixed(2)},${(s.commissionUSD||0).toFixed(2)},${commCAD.toFixed(2)},${ev.gainLossUSD!=null?ev.gainLossUSD.toFixed(2):''},${ev.gainLossCAD!=null?ev.gainLossCAD.toFixed(2):''},"${bdText}","${s.notes||''}"\n`;
  }
  csv += '\n';

  // ── Gain/Loss Report for selected year ──
  csv += `GAIN/LOSS REPORT — ${currentYear}\n`;
  let yrSales = ledger.filter(ev => ev.type === 'sale' && new Date(ev.date).getFullYear() === currentYear);
  let totPC=new Decimal(0),totAC=new Decimal(0),totGC=new Decimal(0);
  let totPU=new Decimal(0),totAU=new Decimal(0),totGU=new Decimal(0);
  csv += 'Date,Shares,FX Rate,Proceeds (CAD),ACB (CAD),Commission (CAD),Gain/Loss (CAD),Proceeds (USD),ACB (USD),Commission (USD),Gain/Loss (USD)\n';
  for (let ev of yrSales) {
    let s = sales[ev.saleIdx];
    let dComm = new Decimal(String(+s.commissionUSD||0));
    let dFx   = new Decimal(String(+s.fx));
    let cCAD  = dComm.times(dFx).toNumber();
    let cUSD  = +s.commissionUSD||0;
    csv += `${ev.date},${s.shares},${s.fx},${ev.proceedsCAD.toFixed(2)},${ev.costCAD.toFixed(2)},${cCAD.toFixed(2)},${ev.gainLossCAD.toFixed(2)},${ev.proceedsUSD.toFixed(2)},${ev.costUSD.toFixed(2)},${cUSD.toFixed(2)},${ev.gainLossUSD.toFixed(2)}\n`;
    totPC = totPC.plus(new Decimal(String(ev.proceedsCAD)));
    totAC = totAC.plus(new Decimal(String(ev.costCAD)));
    totGC = totGC.plus(new Decimal(String(ev.gainLossCAD)));
    totPU = totPU.plus(new Decimal(String(ev.proceedsUSD)));
    totAU = totAU.plus(new Decimal(String(ev.costUSD)));
    totGU = totGU.plus(new Decimal(String(ev.gainLossUSD)));
  }
  csv += `Total,,, ${totPC.toFixed(2)},${totAC.toFixed(2)},,${totGC.toFixed(2)},${totPU.toFixed(2)},${totAU.toFixed(2)},,${totGU.toFixed(2)}\n`;
  csv += `"Taxable Capital Gain (50% inclusion):",,,,,,"${(totGC.gt(0) ? totGC.times('0.5') : new Decimal(0)).toFixed(2)}"\n\n`;

  // ── ACB Ledger ──
  csv += 'ACB LEDGER\n';
  csv += 'Date,Event,Source,Shares Delta,Cost (USD),Cost (CAD),Running Shares,Running ACB (USD),Running ACB (CAD),ACB/Share (USD),ACB/Share (CAD)\n';
  for (let ev of ledger) {
    let isAcq = ev.type !== 'sale';
    let acbPSusd = ev.runShares > 0 ? (ev._decRunACBusd ? ev._decRunACBusd.div(ev._decRunShares).toFixed(4) : (ev.runACBusd / ev.runShares).toFixed(4)) : '';
    let acbPScad = ev.runShares > 0 ? (ev._decRunACBcad ? ev._decRunACBcad.div(ev._decRunShares).toFixed(4) : (ev.runACBcad / ev.runShares).toFixed(4)) : '';
    csv += `${ev.date},${ev.type},${ev.source},${ev.sharesDelta.toFixed(4)},${isAcq?'':'-'}${ev.costUSD.toFixed(2)},${isAcq?'':'-'}${ev.costCAD.toFixed(2)},${ev.runShares.toFixed(4)},${ev.runACBusd.toFixed(2)},${ev.runACBcad.toFixed(2)},${acbPSusd},${acbPScad}\n`;
  }

  let blob = new Blob([csv], { type: 'text/csv' });
  let a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `equity-tracker-${currentYear}.csv`;
  a.click();
  URL.revokeObjectURL(a.href);
  showToast('CSV exported.');
});

// ============================================================
// CLEAR ALL DATA
// ============================================================
document.getElementById('btn-clear-all').addEventListener('click', () => {
  showModal(
    '⚠ Clear All Data?',
    'This will permanently delete ALL grants, ESPP purchases, and sales. This cannot be undone. Export a backup first if needed.',
    () => {
      grants = []; esppPurchases = []; sales = []; dividends = []; skippedDivQuarters = [];
      currentYear = new Date().getFullYear();
      yearInput.value = currentYear;
      renderSales._openYears = {};
      window.acbOpenYears = {};
      saveData(); renderAll();
      showToast('All data cleared.');
    }
  );
});
// ============================================================
// INITIAL RENDER
// ============================================================
renderAll();

// ============================================================
// SCREENSHOT HELP MODAL
// ============================================================
var helpModalConfig = {
  grants: {
    title: 'Where to find RSU Grant info',
    tabs: [
      {
        label: 'New RSU Grant',
        img: 'screenshots/new-rsu-grant.png',
        caption: '<strong>Grant Date, Grant Number &amp; Total Shares Granted</strong> — In At Work, go to <strong>Holdings › Restricted Stock (RS)</strong>, find your grant date, then click <strong>View Grant Documents</strong>.<br><br>Grant Number is also found at <strong>My Account › Benefit History › Restricted Stock (RS)</strong>.'
      },
      {
        label: 'Vest Schedule',
        img: 'screenshots/vest-schedule.png',
        caption: '<strong>Vest Schedule dates &amp; Grant Quantity</strong> — In At Work, go to <strong>Holdings › Restricted Stock (RS)</strong>, find your grant date, then click <strong>Vest Schedule</strong>.<br><br><strong>Shares Sold for Taxes</strong> — Found on your <strong>Stock Plan Release Confirmation</strong> under My Account › Stock Plan Confirmation.'
      },
      {
        label: 'Release Confirmation',
        img: 'screenshots/rsu-stock-release-confirmation.png',
        caption: '<strong>Shares Sold for Taxes</strong> — Look at <strong>Shares Traded</strong> under Stock Distribution. This is the number of shares your broker sold to cover withholding tax.<br><br><strong>Total FMV on Vest Date</strong> — Use the <strong>Market Value</strong> under Calculation of Gain. This is the total USD value of all vested shares on the vest date.'
      }
    ]
  },
  espp: {
    title: 'Where to find ESPP Purchase info',
    tabs: [
      {
        label: 'Add ESPP Purchase',
        img: 'screenshots/add-espp.png',
        caption: '<p style="color:#dc2626;font-weight:600;margin-bottom:10px">⚠ The <strong>Average Exchange Rate</strong> on the ESPP Purchase Confirmation is <strong>CAD→USD</strong> (e.g. $0.756899). Do NOT enter this in the FX Rate (USD→CAD) field. Enter it in the FX Rate (CAD→USD) field instead, or calculate the inverse (1 ÷ 0.756899 = 1.3212) for the USD→CAD field.</p><strong>Purchase Date, Shares &amp; Purchase Price</strong> — Found on your ESPP Purchase Confirmation or At Work › ESPP › Purchase History.<br><br><strong>FMV on Purchase Date</strong> — The market value per share on the purchase date, shown on the same confirmation document.'
      }
    ]
  },
  sales: {
    title: 'Where to find Sale info',
    tabs: [
      {
        label: 'Sale Disposition',
        img: 'screenshots/record-sale-disposition.png',
        caption: '<strong>Order Date</strong> — The date your sale settled. Use this as your Sale Date.<br><br><strong>Sold Qty &amp; Execution Price</strong> — The number of shares sold and the price per share in USD.<br><br><strong>Commission</strong> — Found under Disbursement Details. Enter this in the Commission / Fees field.<br><br><strong>Grant Details (bottom table)</strong> — Shows which grants and vest periods the sold shares came from. Use Grant Number, Vest Period, and Shares to Sell / Shares Sold to fill in the Source Breakdown.'
      },
      {
        label: 'Source Breakdown',
        img: 'screenshots/record-sale-breakdown.png',
        caption: '<strong>Grant ID &amp; Vest Date</strong> — Found on your At Work sale confirmation or brokerage statement. Match the shares sold back to the specific vest periods they came from.<br><br>The source breakdown is for your own tracking — it does not affect the ACB calculation.'
      }
    ]
  }
};

function openHelpModal(section, startTab) {
  var config = helpModalConfig[section];
  if (!config) return;
  startTab = startTab || 0;

  document.getElementById('help-modal-title').textContent = config.title;

  var tabsEl  = document.getElementById('help-modal-tabs');
  var bodyEl  = document.getElementById('help-modal-body');
  tabsEl.innerHTML = '';
  bodyEl.innerHTML = '';

  config.tabs.forEach(function(tab, i) {
    var btn = document.createElement('button');
    btn.className = 'help-tab-btn' + (i === startTab ? ' active' : '');
    btn.textContent = tab.label;
    btn.onclick = function() { switchHelpTab(section, i); };
    tabsEl.appendChild(btn);

    var panel = document.createElement('div');
    panel.className = 'help-tab-panel' + (i === startTab ? ' active' : '');
    panel.id = 'help-panel-' + section + '-' + i;

    var imgHtml = '<img src="' + tab.img + '" alt="' + tab.label + '" class="help-screenshot" '
      + 'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'flex\'">'
      + '<div class="help-screenshot-placeholder" style="display:none">'
      + '<span>🖼</span>Screenshot coming soon<small style="color:#bbb">' + tab.img + '</small></div>';

    panel.innerHTML = imgHtml + '<p class="help-caption">' + tab.caption + '</p>';
    bodyEl.appendChild(panel);
  });

  document.getElementById('help-modal-overlay').classList.remove('hidden');
}

function switchHelpTab(section, idx) {
  var config = helpModalConfig[section];
  document.querySelectorAll('.help-tab-btn').forEach(function(b, i) {
    b.classList.toggle('active', i === idx);
  });
  config.tabs.forEach(function(_, i) {
    var p = document.getElementById('help-panel-' + section + '-' + i);
    if (p) p.classList.toggle('active', i === idx);
  });
}

function closeHelpModal(e) {
  if (e && e.target !== document.getElementById('help-modal-overlay')) return;
  document.getElementById('help-modal-overlay').classList.add('hidden');
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeHelpModal(null);
});

// ============================================================
// USER GUIDE PDF MODAL
// ============================================================
function openUserGuide() {
  var overlay = document.getElementById('guide-modal-overlay');
  var iframe  = document.getElementById('guide-iframe');
  iframe.src = 'UserGuide.pdf';
  overlay.classList.remove('hidden');
}

function closeUserGuide(e) {
  if (e && e.target !== document.getElementById('guide-modal-overlay')) return;
  var overlay = document.getElementById('guide-modal-overlay');
  overlay.classList.add('hidden');
  document.getElementById('guide-iframe').src = '';
}

// ============================================================
// DIVIDENDS
// ============================================================

var divCurrentType = 'cash';

function setDivType(type) {
  divCurrentType = type;
  document.getElementById('div-btn-cash').classList.toggle('active', type === 'cash');
  document.getElementById('div-btn-drip').classList.toggle('active', type === 'drip');
  document.querySelectorAll('.div-drip-field').forEach(function(el) {
    el.classList.toggle('hidden', type === 'cash');
  });
  updateDivPreview();
}

// FX fetch for dividend form
document.getElementById('df-date').addEventListener('change', function() {
  var d = document.getElementById('df-fx');
  d.value = '';
  fetchFX(this.value, document.getElementById('df-fx-display'), d);
  updateDivPreview();
});
['df-gross','df-withheld','df-fx','df-drip-shares','df-drip-price'].forEach(function(id) {
  var el = document.getElementById(id);
  if (el) el.addEventListener('input', updateDivPreview);
});

function updateDivPreview() {
  var gross    = parseFloat(document.getElementById('df-gross').value) || 0;
  var withheld = parseFloat(document.getElementById('df-withheld').value) || 0;
  var fx       = parseFloat(document.getElementById('df-fx').value) || 0;
  var prev     = document.getElementById('df-preview');
  if (!gross || !fx) { prev.innerHTML = ''; return; }
  var dGross   = new Decimal(String(gross));
  var dWith    = new Decimal(String(withheld));
  var dFx      = new Decimal(String(fx));
  var dNetUSD  = dGross.minus(dWith);
  var dGrossCAD= dGross.times(dFx);
  var dWithCAD = dWith.times(dFx);
  var dNetCAD  = dNetUSD.times(dFx);

  var html = '<div class="preview-item"><div class="preview-label">Gross (USD)</div><div class="preview-value">' + fmtUSD(dGross.toNumber()) + '</div></div>'
           + '<div class="preview-item"><div class="preview-label">Withheld (USD)</div><div class="preview-value">' + fmtUSD(dWith.toNumber()) + '</div></div>'
           + '<div class="preview-item"><div class="preview-label">Net (USD)</div><div class="preview-value">' + fmtUSD(dNetUSD.toNumber()) + '</div></div>'
           + '<div class="preview-item"><div class="preview-label">Gross (CAD)</div><div class="preview-value">' + fmtCAD(dGrossCAD.toNumber()) + '</div></div>'
           + '<div class="preview-item"><div class="preview-label">Withheld (CAD)</div><div class="preview-value">' + fmtCAD(dWithCAD.toNumber()) + '</div></div>'
           + '<div class="preview-item"><div class="preview-label">Net (CAD)</div><div class="preview-value">' + fmtCAD(dNetCAD.toNumber()) + '</div></div>';

  if (divCurrentType === 'drip') {
    var dripShares = parseFloat(document.getElementById('df-drip-shares').value) || 0;
    var dripPrice  = parseFloat(document.getElementById('df-drip-price').value) || 0;
    var dAcbAdded  = new Decimal(String(dripShares)).times(new Decimal(String(dripPrice))).times(dFx);
    html += '<div class="preview-item"><div class="preview-label">DRIP Shares</div><div class="preview-value">' + fmtN(dripShares) + '</div></div>'
          + '<div class="preview-item"><div class="preview-label">ACB Added (CAD)</div><div class="preview-value">' + fmtCAD(dAcbAdded.toNumber()) + '</div></div>';
  }
  prev.innerHTML = html;
}

// Show/hide form
document.getElementById('btn-add-dividend').addEventListener('click', function() {
  var form = document.getElementById('dividend-form');
  form.classList.remove('hidden');
  document.getElementById('div-form-title').textContent = 'Record Dividend';
  document.getElementById('df-date').value = '';
  document.getElementById('df-gross').value = '';
  document.getElementById('df-withheld').value = '';
  document.getElementById('df-fx').value = '';
  document.getElementById('df-fx-display').textContent = '';
  document.getElementById('df-drip-shares').value = '';
  document.getElementById('df-drip-price').value = '';
  document.getElementById('df-notes').value = '';
  document.getElementById('df-preview').innerHTML = '';
  divCurrentType = 'cash';
  setDivType('cash');
  divEditIndex = null;
});

document.getElementById('btn-cancel-dividend').addEventListener('click', function() {
  document.getElementById('dividend-form').classList.add('hidden');
  divEditIndex = null;
});

var divEditIndex = null;

document.getElementById('btn-save-dividend').addEventListener('click', function() {
  var date     = document.getElementById('df-date').value;
  var gross    = parseFloat(document.getElementById('df-gross').value);
  var withheld = parseFloat(document.getElementById('df-withheld').value) || 0;
  var fx       = parseFloat(document.getElementById('df-fx').value);
  var notes    = document.getElementById('df-notes').value.trim();

  if (!date || isNaN(gross) || isNaN(fx)) {
    alert('Please fill in Payment Date, Gross Dividend, and FX Rate.'); return;
  }

  var entry = { date: date, type: divCurrentType, grossUSD: gross, withheldUSD: withheld, fx: fx, notes: notes };

  if (divCurrentType === 'drip') {
    var ds = parseFloat(document.getElementById('df-drip-shares').value);
    var dp = parseFloat(document.getElementById('df-drip-price').value);
    if (isNaN(ds) || isNaN(dp)) { alert('Please enter DRIP Shares and Price per Share.'); return; }
    entry.dripShares = ds;
    entry.dripPriceUSD = dp;
  }

  if (divEditIndex !== null) {
    dividends[divEditIndex] = entry;
  } else {
    dividends.push(entry);
  }

  dividends.sort(function(a, b) { return b.date.localeCompare(a.date); });
  document.getElementById('dividend-form').classList.add('hidden');
  divEditIndex = null;
  saveData(); renderAll();
});

function editDividend(i) {
  var e = dividends[i];
  divEditIndex = i;
  divCurrentType = e.type;
  setDivType(e.type);
  document.getElementById('df-date').value    = e.date;
  document.getElementById('df-gross').value   = e.grossUSD;
  document.getElementById('df-withheld').value= e.withheldUSD || '';
  document.getElementById('df-fx').value      = e.fx;
  document.getElementById('df-fx-display').textContent = '1 USD = ' + parseFloat(e.fx).toFixed(4) + ' CAD';
  document.getElementById('df-drip-shares').value = e.dripShares || '';
  document.getElementById('df-drip-price').value  = e.dripPriceUSD || '';
  document.getElementById('df-notes').value   = e.notes || '';
  document.getElementById('div-form-title').textContent = 'Edit Dividend';
  document.getElementById('dividend-form').classList.remove('hidden');
  updateDivPreview();
}

function deleteDividend(i) {
  showModal('Delete Dividend?', 'Remove this dividend entry?', function() {
    dividends.splice(i, 1);
    saveData(); renderAll();
  });
}

// ── Upcoming dividend dates ──
function getUpcomingDividends() {
  var today = new Date();
  today.setHours(0, 0, 0, 0);
  var cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() - 90); // show missed quarters up to 90 days past

  var results = [];
  var months = [0, 3, 6, 9];
  for (var y = today.getFullYear() - 1; y <= today.getFullYear() + 1; y++) {
    months.forEach(function(m) {
      var date = thirdFriday(y, m);
      if (date < cutoff) return;
      if (results.length >= 4) return;

      var monthKey = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');

      // Skip if user dismissed this quarter
      if (skippedDivQuarters.indexOf(monthKey) !== -1) return;

      // Check if already recorded within ±15 days
      var alreadyRecorded = dividends.some(function(d) {
        var dd = new Date(d.date + 'T00:00:00');
        return Math.abs(dd - date) <= 15 * 24 * 60 * 60 * 1000;
      });
      if (alreadyRecorded) return;

      var isPast = date < today;
      results.push({ date: date, monthKey: monthKey, iso: date.toISOString().split('T')[0], missed: isPast });
    });
  }
  return results.slice(0, 3);
}

function skipDivQuarter(monthKey) {
  if (skippedDivQuarters.indexOf(monthKey) === -1) {
    skippedDivQuarters.push(monthKey);
  }
  saveData();
  renderDividends();
}

function thirdFriday(year, month) {
  var d = new Date(year, month, 1);
  var fri = (5 - d.getDay() + 7) % 7; // days until first Friday
  d.setDate(1 + fri + 14); // 3rd Friday
  return d;
}

function fmtDateStr(d) {
  return d.toLocaleDateString('en-CA', { year: 'numeric', month: 'short', day: 'numeric' });
}

function prefillDivDate(dateStr) {
  document.getElementById('btn-add-dividend').click();
  setTimeout(function() {
    document.getElementById('df-date').value = dateStr;
    fetchFX(dateStr, document.getElementById('df-fx-display'), document.getElementById('df-fx'));
  }, 50);
}

// ── Render dividends ──
function renderDividends() {
  var body     = document.getElementById('div-body');
  var foot     = document.getElementById('div-foot');
  var annBody  = document.getElementById('div-annual-body');
  var upcoming = document.getElementById('div-upcoming');
  var sumCards = document.getElementById('div-summary-cards');

  // Upcoming panel
  var upDates = getUpcomingDividends();
  var qLabels = ['Q1','Q2','Q3','Q4'];
  var upHTML = '<div class="div-upcoming-title">📅 Expected Dividend Payments</div>';
  if (upDates.length === 0) {
    upHTML += '<div class="div-upcoming-row"><span class="div-upcoming-hint">All expected payments are recorded. Next ones will appear as they approach.</span></div>';
  } else {
    upDates.forEach(function(item) {
      var qIdx = Math.floor(item.date.getMonth() / 3);
      var monthStr = item.date.toLocaleDateString('en-CA', { month: 'long', year: 'numeric' });
      if (item.missed) {
        upHTML += '<div class="div-upcoming-row div-missed-row">'
          + '<span class="div-upcoming-date">⚠ ' + monthStr + '</span>'
          + '<span class="div-upcoming-hint">' + qLabels[qIdx] + ' · No dividend recorded — did you receive one?</span>'
          + '<div style="display:flex;gap:6px">'
          + '<button class="btn-record-div" onclick="prefillDivDate(\'' + item.iso + '\')">Record</button>'
          + '<button class="btn-skip-div" onclick="skipDivQuarter(\'' + item.monthKey + '\')">Skip</button>'
          + '</div>'
          + '</div>';
      } else {
        upHTML += '<div class="div-upcoming-row">'
          + '<span class="div-upcoming-date">' + monthStr + '</span>'
          + '<span class="div-upcoming-hint">' + qLabels[qIdx] + ' · estimated</span>'
          + '<button class="btn-record-div" onclick="prefillDivDate(\'' + item.iso + '\')">Record</button>'
          + '</div>';
      }
    });
  }
  upcoming.innerHTML = upHTML;

  // History table
  body.innerHTML = '';
  if (!dividends || dividends.length === 0) {
    body.innerHTML = '<tr><td colspan="13" class="muted">No dividends recorded yet.</td></tr>';
    foot.innerHTML = '';
  } else {
    dividends.forEach(function(e, i) {
      var dGross   = new Decimal(String(+e.grossUSD));
      var dWith    = new Decimal(String(+e.withheldUSD || 0));
      var dFx      = new Decimal(String(+e.fx));
      var dNetUSD  = dGross.minus(dWith);
      var dGrossCAD= dGross.times(dFx);
      var dWithCAD = dWith.times(dFx);
      var dNetCAD  = dNetUSD.times(dFx);
      var tag      = e.type === 'drip'
        ? '<span class="tag tag-drip">DRIP</span>'
        : '<span class="tag tag-cash">Cash</span>';
      var dripShares = e.dripShares ? fmtN(e.dripShares) : '—';
      var dripPrice  = e.dripPriceUSD ? fmtUSD(e.dripPriceUSD) : '—';
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>' + e.date + '</td>'
        + '<td>' + tag + '</td>'
        + '<td>' + fmtUSD(dGross.toNumber()) + '</td>'
        + '<td style="color:var(--loss)">(' + fmtUSD(dWith.toNumber()) + ')</td>'
        + '<td>' + fmtUSD(dNetUSD.toNumber()) + '</td>'
        + '<td>' + parseFloat(e.fx).toFixed(4) + '</td>'
        + '<td class="gain">' + fmtCAD(dGrossCAD.toNumber()) + '</td>'
        + '<td style="color:var(--loss)">(' + fmtCAD(dWithCAD.toNumber()) + ')</td>'
        + '<td class="gain">' + fmtCAD(dNetCAD.toNumber()) + '</td>'
        + '<td>' + dripShares + '</td>'
        + '<td>' + dripPrice + '</td>'
        + '<td>' + (e.notes || '—') + '</td>'
        + '<td><button class="btn-sm btn-edit-sm" onclick="editDividend(' + i + ')">Edit</button> '
        + '<button class="btn-sm btn-del-sm" onclick="deleteDividend(' + i + ')">Del</button></td>';
      body.appendChild(tr);
    });
  }

  // Annual summary — use Decimal for accumulation
  var byYear = {};
  dividends.forEach(function(e) {
    var y = new Date(e.date + 'T00:00:00').getFullYear();
    if (!byYear[y]) byYear[y] = { count:0, grossUSD: new Decimal(0), withUSD: new Decimal(0), grossCAD: new Decimal(0), withCAD: new Decimal(0), dripShares: new Decimal(0) };
    var r = byYear[y];
    r.count++;
    r.grossUSD = r.grossUSD.plus(new Decimal(String(+e.grossUSD)));
    r.withUSD  = r.withUSD.plus(new Decimal(String(+e.withheldUSD || 0)));
    r.grossCAD = r.grossCAD.plus(new Decimal(String(+e.grossUSD)).times(new Decimal(String(+e.fx))));
    r.withCAD  = r.withCAD.plus(new Decimal(String(+e.withheldUSD || 0)).times(new Decimal(String(+e.fx))));
    if (e.dripShares) r.dripShares = r.dripShares.plus(new Decimal(String(+e.dripShares)));
  });
  annBody.innerHTML = '';
  var years = Object.keys(byYear).sort(function(a,b){return b-a;});
  if (years.length === 0) {
    annBody.innerHTML = '<tr><td colspan="9" class="muted">No data yet.</td></tr>';
  } else {
    years.forEach(function(y) {
      var r = byYear[y];
      var tr = document.createElement('tr');
      tr.innerHTML = '<td><strong>' + y + '</strong></td>'
        + '<td>' + r.count + '</td>'
        + '<td>' + fmtUSD(r.grossUSD.toNumber()) + '</td>'
        + '<td style="color:var(--loss)">(' + fmtUSD(r.withUSD.toNumber()) + ')</td>'
        + '<td>' + fmtUSD(r.grossUSD.minus(r.withUSD).toNumber()) + '</td>'
        + '<td class="gain">' + fmtCAD(r.grossCAD.toNumber()) + '</td>'
        + '<td style="color:var(--loss)">(' + fmtCAD(r.withCAD.toNumber()) + ')</td>'
        + '<td class="gain">' + fmtCAD(r.grossCAD.minus(r.withCAD).toNumber()) + '</td>'
        + '<td>' + (r.dripShares.gt(0) ? fmtN(r.dripShares.toNumber()) : '—') + '</td>';
      annBody.appendChild(tr);
    });
  }

  // Summary cards for current year
  var yr = currentYear;
  var emptyYear = { count:0, grossUSD: new Decimal(0), withUSD: new Decimal(0), grossCAD: new Decimal(0), withCAD: new Decimal(0), dripShares: new Decimal(0) };
  var yrData = byYear[yr] || emptyYear;
  sumCards.innerHTML =
    '<div class="card card-teal"><div class="card-label">' + yr + ' Gross Dividend (CAD)</div><div class="card-value">' + fmtCAD(yrData.grossCAD.toNumber()) + '</div><div class="card-sub">Report on T1 Schedule 4</div></div>'
  + '<div class="card card-teal"><div class="card-label">' + yr + ' US Tax Withheld (CAD)</div><div class="card-value">' + fmtCAD(yrData.withCAD.toNumber()) + '</div><div class="card-sub">Claim as foreign tax credit</div></div>'
  + '<div class="card card-teal"><div class="card-label">' + yr + ' Net Dividend (CAD)</div><div class="card-value">' + fmtCAD(yrData.grossCAD.minus(yrData.withCAD).toNumber()) + '</div><div class="card-sub">' + yrData.count + ' payment' + (yrData.count !== 1 ? 's' : '') + ' this year</div></div>'
  + '<div class="card card-teal"><div class="card-label">' + yr + ' DRIP Shares Received</div><div class="card-value">' + (yrData.dripShares.gt(0) ? fmtN(yrData.dripShares.toNumber()) : '0') + '</div><div class="card-sub">Added to ACB pool</div></div>';
}
